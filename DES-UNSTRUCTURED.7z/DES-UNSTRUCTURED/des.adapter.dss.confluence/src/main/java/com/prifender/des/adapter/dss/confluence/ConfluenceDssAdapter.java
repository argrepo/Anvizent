package com.prifender.des.adapter.dss.confluence;

import static com.prifender.des.util.DatabaseUtil.createDir;
import static com.prifender.des.util.DatabaseUtil.getConvertedDate;
import static com.prifender.des.util.DatabaseUtil.getUUID;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.xml.rpc.ServiceException;
import org.springframework.stereotype.Component;
import org.swift.common.soap.confluence.AuthenticationFailedException;
import org.swift.common.soap.confluence.ConfluenceSoapService;
import org.swift.common.soap.confluence.ConfluenceSoapServiceServiceLocator;
import org.swift.common.soap.confluence.InvalidSessionException;
import org.swift.common.soap.confluence.RemoteException;
import org.swift.common.soap.confluence.RemotePageSummary;
import org.swift.common.soap.confluence.RemoteSpace;
import org.swift.common.soap.confluence.RemoteSpaceSummary;
import com.prifender.des.DataExtractionServiceException;
import com.prifender.des.controller.DataExtractionContext;
import com.prifender.des.controller.DataExtractionThread;
import com.prifender.des.controller.DataSourceAdapter;
import com.prifender.des.model.ConnectionParamDef;
import com.prifender.des.model.ConnectionParamDef.TypeEnum;
import com.prifender.des.model.ConnectionStatus;
import com.prifender.des.model.DataExtractionJob;
import com.prifender.des.model.DataExtractionSpec;
import com.prifender.des.model.DataExtractionTask;
import com.prifender.des.model.DataSource;
import com.prifender.des.model.DataSourceType;
import com.prifender.des.model.FileMetaInfo;
import com.prifender.des.model.Metadata;
import com.prifender.des.model.Problem;

@Component
public class ConfluenceDssAdapter extends DataSourceAdapter
{

	// End point
	public static final String PARAM_ENDPOINT_ID = "EndPoint";
	public static final String PARAM_ENDPOINT_LABEL = "EndPoint";
	public static final String PARAM_ENDPOINT_DESCRIPTION = "End Point For Confluence Authentication";

	public static final ConnectionParamDef PARAM_ENDPOINT = new ConnectionParamDef().id(PARAM_ENDPOINT_ID).label(PARAM_ENDPOINT_LABEL).description(PARAM_ENDPOINT_DESCRIPTION).type(TypeEnum.STRING);

	// Space
	public static final String PARAM_SPACE_KEY_ID = "SpaceKey";
	public static final String PARAM_SPACE_KEY_LABEL = "SpaceKey";
	public static final String PARAM_SPACE_KEY_DESCRIPTION = "Name of the Space Key to get the pages";

	public static final ConnectionParamDef PARAM_SPACE = new ConnectionParamDef().id(PARAM_SPACE_KEY_ID).label(PARAM_SPACE_KEY_LABEL).description(PARAM_SPACE_KEY_DESCRIPTION).type(TypeEnum.STRING).required(false);

	public static final String TYPE_ID = "Confluence";
	public static final String TYPE_LABEL = "Confluence";

	private static final DataSourceType TYPE = new DataSourceType().id(TYPE_ID).label(TYPE_LABEL).addConnectionParamsItem(PARAM_USER).addConnectionParamsItem(PARAM_PASSWORD).addConnectionParamsItem(PARAM_HOST).addConnectionParamsItem(clone(PARAM_PORT).defaultValue("8090").required(false))
			.addConnectionParamsItem(PARAM_ENDPOINT).addConnectionParamsItem(PARAM_SPACE);

	@Override
	public DataSourceType getDataSourceType()
	{
		return TYPE;
	}

	@Override
	public ConnectionStatus testConnection(DataSource ds) throws DataExtractionServiceException
	{
		ConfluenceSoapService confluenceSoapService = null;
		String token = null;
		List<String> spacesList = null;
		try
		{
			confluenceSoapService = getConnection(ds);
			final String space = getConnectionParam(ds, PARAM_SPACE_KEY_ID);
			if( confluenceSoapService != null )
			{
				token = getTokenFromConfluenceSoapService(confluenceSoapService, ds);
				if( token != null )
				{
					spacesList = getSpacesFromConfluenceSoapService(confluenceSoapService, token, ds);
					if( spacesList != null && spacesList.size() > 0 )
					{
						return new ConnectionStatus().code(ConnectionStatus.CodeEnum.SUCCESS).message("Confluence Authorization Successful.");
					}
					else
					{
						return new ConnectionStatus().code(ConnectionStatus.CodeEnum.FAILURE).message("The Space key '" + space + "' is not found in datasource.");
					}

				}
			}
		}
		catch ( ServiceException e )
		{
			return new ConnectionStatus().code(ConnectionStatus.CodeEnum.FAILURE).message(e.getMessage());
		}
		catch ( AuthenticationFailedException e )
		{
			return new ConnectionStatus().code(ConnectionStatus.CodeEnum.FAILURE).message(e.getFaultString());
		}
		catch ( RemoteException e )
		{
			return new ConnectionStatus().code(ConnectionStatus.CodeEnum.FAILURE).message(e.getFaultString());
		}
		catch ( IllegalArgumentException iae )
		{
			return new ConnectionStatus().code(ConnectionStatus.CodeEnum.FAILURE).message(iae.getMessage());
		}
		catch ( Exception e )
		{
			return new ConnectionStatus().code(ConnectionStatus.CodeEnum.FAILURE).message(e.getMessage());
		}

		return new ConnectionStatus().code(ConnectionStatus.CodeEnum.FAILURE).message("Confluence Authorization Failed.");
	}

	private ConfluenceSoapService getConnection(final DataSource ds) throws AuthenticationFailedException, java.rmi.RemoteException, ServiceException
	{
		if( ds == null )
		{
			throw new IllegalArgumentException("datasource is null");
		}

		final String host = getConnectionParam(ds, PARAM_HOST_ID);
		final String port = getConnectionParam(ds, PARAM_PORT_ID);
		final String endPoint = getConnectionParam(ds, PARAM_ENDPOINT_ID);

		ConfluenceSoapServiceServiceLocator confluenceSoapServiceServiceLocator = new ConfluenceSoapServiceServiceLocator();
		confluenceSoapServiceServiceLocator.setConfluenceserviceV2EndpointAddress("http://" + host + ":" + port + endPoint);
		confluenceSoapServiceServiceLocator.setMaintainSession(true);
		return confluenceSoapServiceServiceLocator.getConfluenceserviceV2();
	}

	private String getTokenFromConfluenceSoapService(ConfluenceSoapService confluenceSoapService, DataSource ds) throws AuthenticationFailedException, RemoteException, java.rmi.RemoteException
	{

		final String userName = getConnectionParam(ds, PARAM_USER_ID);
		final String password = getConnectionParam(ds, PARAM_PASSWORD_ID);
		return confluenceSoapService.login(userName, password);
	}

	private String getTokenFromConfluenceSoapService(ConfluenceSoapService confluenceSoapService, String userName, String password) throws AuthenticationFailedException, RemoteException, java.rmi.RemoteException
	{
		return confluenceSoapService.login(userName, password);
	}

	@SuppressWarnings("unused")
	List<String> getSpacesFromConfluenceSoapService(ConfluenceSoapService confluenceSoapService, String token, DataSource ds) throws InvalidSessionException, RemoteException, java.rmi.RemoteException
	{
		List<String> spaceNames = null;

		final String space = getConnectionParam(ds, PARAM_SPACE_KEY_ID);

		RemoteSpaceSummary[] remoteSpaceSummaryArray = confluenceSoapService.getSpaces(token);

		if( remoteSpaceSummaryArray.length == 0 && remoteSpaceSummaryArray == null )
		{
			throw new IllegalArgumentException("No spaces found in datasource '" + ds.getId() + "'");
		}
		else
		{
			if( space == null )
			{
				for (RemoteSpaceSummary remoteSpaceSummary : remoteSpaceSummaryArray)

				{
					spaceNames = new ArrayList<String>();
					spaceNames.add(remoteSpaceSummary.getKey());
				}
			}
			else
			{
				for (RemoteSpaceSummary remoteSpaceSummary : remoteSpaceSummaryArray)
				{
					if( remoteSpaceSummary.getKey().equals(space) )
					{
						spaceNames = new ArrayList<String>();
						spaceNames.add(remoteSpaceSummary.getKey());
						break;
					}

				}
			}

		}

		return spaceNames;
	}

	@Override
	public Metadata getMetadata(final DataSource ds) throws DataExtractionServiceException
	{
		Metadata metadata = getMetadataForUnstructuredDS(ds);
		return metadata;
	}

	@Override
	public StartResult startDataExtractionJob(DataSource ds, DataExtractionSpec spec, final int containersCount) throws DataExtractionServiceException
	{
		StartResult startResult = null;
		try
		{
			final DataExtractionJob job = createDataExtractionJob(ds, spec);
			String adapterHome = createDir(this.desHome, TYPE_LABEL);
			final DataExtractionContext context = new DataExtractionContext(this, getDataSourceType(), ds, spec, job, this.messaging, this.pendingTasksQueue, this.pendingTasksQueueName, TYPE_LABEL, this.encryption);
			final DataExtractionThread dataExtractionExecutor = new ConfluenceDataExtractionExecutor(context, adapterHome, containersCount);
			this.threadPool.execute(dataExtractionExecutor);
			startResult = new StartResult(job, dataExtractionExecutor);
		}
		catch ( Exception exe )
		{
			throw new DataExtractionServiceException(new Problem().code("unknownDataExtractionJob").message(exe.getMessage()));

		}
		return startResult;
	}

	public class ConfluenceDataExtractionExecutor extends DataExtractionThread
	{
		private final int containersCount;

		public ConfluenceDataExtractionExecutor(final DataExtractionContext context, final String adapterHome, final int containersCount) throws DataExtractionServiceException
		{
			super(context);
			this.containersCount = containersCount;
		}

		@Override
		protected List<DataExtractionTask> runDataExtractionJob() throws Exception
		{
			final DataSource ds = this.context.ds;
			final DataExtractionSpec spec = this.context.spec;
			final DataExtractionJob job = this.context.job;

			return getDataExtractionTasks(ds, spec, job, containersCount);
		}

		private List<DataExtractionTask> getDataExtractionTasks(DataSource ds, DataExtractionSpec spec,

				DataExtractionJob job, int containersCount) throws DataExtractionServiceException
		{

			List<DataExtractionTask> dataExtractionJobTasks = new ArrayList<DataExtractionTask>();

			int objectsCount = 0;
			int tasksCount = 0;

			try
			{
				synchronized (job)
				{
					job.setOutputMessagingQueue("DES-" + job.getId());

					job.objectsExtracted(0);

					job.setTasksCount(tasksCount);

					job.setObjectCount(objectsCount);
				}

				List<FileMetaInfo> fileMetaInfoList = getFilesInfoList(ds);

				for (FileMetaInfo fileMetaInfo : fileMetaInfoList)
				{

					if( fileMetaInfo.getFileSize() != 0 )
					{
						dataExtractionJobTasks.add(getDataExtractionTask(ds, spec, job, fileMetaInfo));
						tasksCount++;

						if( "SAMPLE".equals(spec.getScope().name()) )
						{
							objectsCount += fileMetaInfo.getFileSize() < spec.getSampleSize() ? fileMetaInfo.getFileSize() : spec.getSampleSize();
						}
						else
						{
							objectsCount += fileMetaInfo.getFileSize();
						}
					}

				}
			}
			catch ( Exception e )
			{
				throw new DataExtractionServiceException(new Problem().code("unknownDataExtractionJob").message(e.getMessage()));
			}
			synchronized (job)
			{
				job.setTasksCount(tasksCount);
				job.setObjectCount(objectsCount);
			}

			return dataExtractionJobTasks;
		}

		private final DataExtractionTask getDataExtractionTask(DataSource ds, DataExtractionSpec spec,

				DataExtractionJob job, FileMetaInfo filesInfo) throws DataExtractionServiceException
		{

			DataExtractionTask dataExtractionTask = new DataExtractionTask();

			try
			{

				final String host = getConnectionParam(ds, PARAM_HOST_ID);
				final String port = getConnectionParam(ds, PARAM_PORT_ID);
				final String endPoint = getConnectionParam(ds, PARAM_ENDPOINT_ID);
				final String userName = filesInfo.getFileId(); // getConnectionParam(ds,
																// PARAM_USER_ID);
				final String spaceKey = filesInfo.getFileName();
				final String spaceName = filesInfo.getFilePath();

				final String password = getConnectionParam(ds, PARAM_PASSWORD_ID);

				Map<String, String> contextParams = getContextParams(job.getId(), userName, password, host, port, endPoint, spaceKey, spec.getScope().name(), String.valueOf(spec.getSampleSize()), spaceName);

				dataExtractionTask.taskId("DES-Task-" + getUUID())

						.jobId(job.getId())

						.typeId(TYPE_ID)

						.contextParameters(contextParams)

						.numberOfFailedAttempts(0);
			}
			catch ( Exception e )
			{
				throw new DataExtractionServiceException(new Problem().code("unknownDataExtractionJob").message(e.getMessage()));
			}
			return dataExtractionTask;
		}

		private Map<String, String> getContextParams(String jobId, String userName, String password, String hostName, String port, String endPoint, String spaceKey, final String extractionScope, final String sampleSize, String spaceName) throws IOException
		{

			Map<String, String> contextParams = new LinkedHashMap<>();

			contextParams.put("JOB_STARTDATETIME", getConvertedDate(new Date()));

			contextParams.put("DATASOURCE_USER", userName);

			contextParams.put("DATASOURCE_PORT", port);

			contextParams.put("DATASOURCE_HOST", hostName);

			contextParams.put("DATASOURCE_PASS", password);

			contextParams.put("DATASOURCE_ENDPOINT", endPoint);

			contextParams.put("SCOPE", extractionScope);

			contextParams.put("SAMPLESIZE", sampleSize);

			contextParams.put("JOB_ID", jobId);

			contextParams.put("DATASOURCE_SPACE_KEY", spaceKey);

			contextParams.put("DATASOURCE_SPACE_NAME", spaceName);

			return contextParams;
		}

		private List<FileMetaInfo> getFilesInfoList(final DataSource ds) throws DataExtractionServiceException
		{

			List<FileMetaInfo> filesInfoList = new ArrayList<>();
			try
			{
				ConfluenceSoapService confluenceSoapService = getConnection(ds);

				String token = getTokenFromConfluenceSoapService(confluenceSoapService, ds);

				String[] usersArray = confluenceSoapService.getActiveUsers(token, true);

				for (String userName : usersArray)
				{

					final String password = getConnectionParam(ds, PARAM_PASSWORD_ID);

					token = getTokenFromConfluenceSoapService(confluenceSoapService, userName, password);

					if( confluenceSoapService != null && token != null )
					{
						final String space = getConnectionParam(ds, PARAM_SPACE_KEY_ID);

						if( space == null )
						{
							try
							{
								RemoteSpaceSummary[] remoteSpaceSummaryArray = confluenceSoapService.getSpaces(token);

								if( remoteSpaceSummaryArray.length > 0 && remoteSpaceSummaryArray != null )
								{
									for (RemoteSpaceSummary remoteSpaceSummary : remoteSpaceSummaryArray)
									{
										if( remoteSpaceSummary != null )
										{
										 
											RemotePageSummary[] remotePageSummaryArray = confluenceSoapService.getPages(token, remoteSpaceSummary.getKey());

											if( remotePageSummaryArray.length > 0 && remotePageSummaryArray != null )
											{
												FileMetaInfo fileMetaInfo = new FileMetaInfo();
												fileMetaInfo.setFilePath(remoteSpaceSummary.getName());
												fileMetaInfo.setFileId(userName);
												fileMetaInfo.setFileName(remoteSpaceSummary.getKey());
												fileMetaInfo.setFileSize(remotePageSummaryArray.length);
												filesInfoList.add(fileMetaInfo);
											}
										}

									}

								}
							}
							catch ( RemoteException e )
							{
								e.printStackTrace();
							}
						}
						else
						{
							try
							{
								RemoteSpace remoteSpace = confluenceSoapService.getSpace(token, space);
								if( remoteSpace != null )
								{
									RemotePageSummary[] remotePageSummaryArray = confluenceSoapService.getPages(token, remoteSpace.getKey());
									if( remotePageSummaryArray.length > 0 && remotePageSummaryArray != null )
									{
										FileMetaInfo fileMetaInfo = new FileMetaInfo();
										fileMetaInfo.setFilePath(remoteSpace.getName());
										fileMetaInfo.setFileId(userName);
										fileMetaInfo.setFileName(remoteSpace.getKey());
										fileMetaInfo.setFileSize(remotePageSummaryArray.length);
										filesInfoList.add(fileMetaInfo);
									}
								}
							}
							catch ( RemoteException e )
							{
								e.printStackTrace();
							}
						}

					}
				}
			}
			catch ( ServiceException e )
			{
				throw new DataExtractionServiceException(new Problem().code("unknownConnection").message(e.getMessage()));
			}
			catch ( AuthenticationFailedException e )
			{
				throw new DataExtractionServiceException(new Problem().code("unknownConnection").message(e.getFaultString()));
			}
			catch ( RemoteException e )
			{
				throw new DataExtractionServiceException(new Problem().code("unknownConnection").message(e.getFaultString()));
			}
			catch ( Exception e )
			{
				throw new DataExtractionServiceException(new Problem().code("unknownConnection").message(e.getMessage()));
			}
			return filesInfoList;
		}
	}

	@Override
	public int getCountRows(DataSource ds, DataExtractionSpec spec) throws DataExtractionServiceException
	{
		return 0;
	}
}
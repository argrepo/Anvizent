package com.prifender.des.adapter.filesystem.samba;

import static com.prifender.des.util.DatabaseUtil.createDir;
import static com.prifender.des.util.DatabaseUtil.getConvertedDate;
import static com.prifender.des.util.DatabaseUtil.getUUID;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.prifender.des.DataExtractionServiceException;
import com.prifender.des.controller.DataExtractionContext;
import com.prifender.des.controller.DataExtractionThread;
import com.prifender.des.controller.DataSourceAdapter;
import com.prifender.des.model.ConnectionParamDef;
import com.prifender.des.model.ConnectionParamDef.TypeEnum;
import com.prifender.des.model.ConnectionStatus;
import com.prifender.des.model.DataExtractionJob;
import com.prifender.des.model.DataExtractionSpec;
import com.prifender.des.model.DataExtractionTask;
import com.prifender.des.model.DataSource;
import com.prifender.des.model.DataSourceType;
import com.prifender.des.model.FileMetaInfo;
import com.prifender.des.model.Metadata;
import com.prifender.des.model.NamedType;
import com.prifender.des.model.Problem;
import com.prifender.des.model.Type;

import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbException;
import jcifs.smb.SmbFile;

@Component
public final class SambaDataSourceAdapter extends DataSourceAdapter
{

	private static final int MAX_FILES_THRESHOLD = 10;

	@Value("${des.home}")
	private String desHome;

	@Value("${scheduling.taskStatusQueue}")
	private String taskStatusQueueName;

	public static final String TYPE_ID = "Samba";
	public static final String TYPE_LABEL = "Samba";

	// File
	public static final String PARAM_FILE_ID = "FilePath";
	public static final String PARAM_FILE_LABEL = "FilePath";
	public static final String PARAM_FILE_DESCRIPTION = "The path of the file";

	public static final ConnectionParamDef PARAM_FILE = new ConnectionParamDef().id(PARAM_FILE_ID).label(PARAM_FILE_LABEL).description(PARAM_FILE_DESCRIPTION).type(TypeEnum.STRING).required(false);

	// ShareName
	public static final String PARAM_SHARE_ID = "Share";
	public static final String PARAM_SHARE_LABEL = "Share";
	public static final String PARAM_SHARE_DESCRIPTION = "The File Share Name";

	public static final ConnectionParamDef PARAM_SHARE = new ConnectionParamDef().id(PARAM_SHARE_ID).label(PARAM_SHARE_LABEL).description(PARAM_SHARE_DESCRIPTION).type(TypeEnum.STRING);

	// SMB Authentication

	public static final String PARAM_SMB_AUTHENTICATION_ID = "SmbAuthentication";
	public static final String PARAM_SMB_AUTHENTICATION_LABEL = "Smb Authentication";
	public static final String PARAM_SMB_AUTHENTICATION_DESCRIPTION = "The Smb Authentication for file";

	public static final ConnectionParamDef PARAM_SMB_AUTHENTICATION = new ConnectionParamDef().id(PARAM_SMB_AUTHENTICATION_ID).label(PARAM_SMB_AUTHENTICATION_LABEL).description(PARAM_SMB_AUTHENTICATION_DESCRIPTION).type(TypeEnum.BOOLEAN);

	/*
	 * private static final DataSourceType TYPE = new
	 * DataSourceType().id(TYPE_ID).label(TYPE_LABEL)
	 * .addConnectionParamsItem(clone(PARAM_HOST).required(false))
	 * .addConnectionParamsItem(PARAM_SHARE)
	 * .addConnectionParamsItem(clone(PARAM_USER).required(false))
	 * .addConnectionParamsItem(clone(PARAM_PASSWORD).required(false))
	 * .addConnectionParamsItem(PARAM_SMB_AUTHENTICATION)
	 * .addConnectionParamsItem(PARAM_FILE);
	 */

	private static final DataSourceType TYPE = new DataSourceType().id(TYPE_ID).label(TYPE_LABEL).addConnectionParamsItem(PARAM_HOST).addConnectionParamsItem(PARAM_SHARE).addConnectionParamsItem(PARAM_USER).addConnectionParamsItem(PARAM_PASSWORD).addConnectionParamsItem(PARAM_SMB_AUTHENTICATION)
			.addConnectionParamsItem(PARAM_FILE);

	@Override
	public DataSourceType getDataSourceType()
	{
		return TYPE;
	}

	@Override
	public ConnectionStatus testConnection(DataSource ds) throws DataExtractionServiceException
	{
		SmbFile smbFile = null;
		File file = null;
		try
		{
			final boolean smbAuth = Boolean.parseBoolean(getConnectionParam(ds, PARAM_SMB_AUTHENTICATION_ID));
			if( smbAuth )
			{
				smbFile = getSmbFileSystem(ds);
				if( smbFile != null )
				{
					return new ConnectionStatus().code(ConnectionStatus.CodeEnum.SUCCESS).message("Samba File System connection successfully established.");
				}
			}
			else
			{
				final String filePath = getConnectionParam(ds, PARAM_FILE_ID);
				if( null != filePath )
				{
					file = getFileSystem(ds);
					if( file != null )
					{
						return new ConnectionStatus().code(ConnectionStatus.CodeEnum.SUCCESS).message("Local File System connection successfully established.");
					}
				}
				else
				{
					return new ConnectionStatus().code(ConnectionStatus.CodeEnum.FAILURE).message("FilePath is required for Local File System.");
				}
			}
		}
		catch ( Exception e )
		{
			return new ConnectionStatus().code(ConnectionStatus.CodeEnum.FAILURE).message(e.getMessage());
		}
		return new ConnectionStatus().code(ConnectionStatus.CodeEnum.FAILURE).message("Could not connect to File System.");
	}

	private SmbFile getSmbFileSystem(DataSource ds) throws DataExtractionServiceException
	{
		SmbFile smbFile = null;
		try
		{
			if( ds == null )
			{
				throw new DataExtractionServiceException(new Problem().code("unknownDataSource").message("datasource is null."));
			}
			final String pathName = getConnectionParam(ds, PARAM_FILE_ID);

			final String userName = getConnectionParam(ds, PARAM_USER_ID);
			final String password = getConnectionParam(ds, PARAM_PASSWORD_ID);
			final String host = getConnectionParam(ds, PARAM_HOST_ID);
			final String shareName = getConnectionParam(ds, PARAM_SHARE_ID);
			if( StringUtils.isNotBlank(userName) && StringUtils.isNotBlank(password) && StringUtils.isNotBlank(host) && StringUtils.isNotBlank(shareName) )
			{
				smbFile = getSmbFile(userName, password, host, shareName, pathName);
			}
			else
			{
				throw new DataExtractionServiceException(new Problem().code("insufficientDetails").message("Host, Share, User and Passowrd are required for Samba File System."));
			}
		}
		catch ( MalformedURLException e )
		{
			throw new DataExtractionServiceException(new Problem().code("Error").message(e.getMessage()));
		}
		return smbFile;
	}

	private SmbFile getSmbFile(String userName, String password, String host, String smbShareName, String filePath) throws MalformedURLException
	{
		NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication(userName + ":" + password);
		String path = "smb://" + host + "/" + smbShareName + "/";

		if( null != filePath )
		{
			path += filePath;
		}

		return new SmbFile(path, auth);
	}

	private SmbFile getSmbFileByPath(String userNamePassword, String path) throws MalformedURLException
	{
		NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication(userNamePassword);
		return new SmbFile(path, auth);
	}

	private File getFileSystem(DataSource ds) throws DataExtractionServiceException
	{
		File file = null;
		try
		{
			final String fileName = getConnectionParam(ds, PARAM_FILE_ID);
			file = getFile(fileName);
		}
		catch ( Exception e )
		{
			throw new DataExtractionServiceException(new Problem().code("unknownFile").message(e.getMessage()));
		}
		return file;
	}

	private File getFile(String fileName)
	{
		return new File(fileName);

	}

	@Override
	public StartResult startDataExtractionJob(DataSource ds, DataExtractionSpec spec, final int containersCount) throws DataExtractionServiceException
	{
		StartResult startResult = null;
		try
		{
			final DataExtractionJob job = createDataExtractionJob(ds, spec);
			String adapterHome = createDir(this.desHome, TYPE_LABEL);
			final DataExtractionContext context = new DataExtractionContext(this, getDataSourceType(), ds, spec, job, this.messaging, this.pendingTasksQueue, this.pendingTasksQueueName, TYPE_LABEL, this.encryption);
			final DataExtractionThread dataExtractionExecutor = new NFSDataExtractionExecutor(context, adapterHome, containersCount);
			this.threadPool.execute(dataExtractionExecutor);
			startResult = new StartResult(job, dataExtractionExecutor);
		}
		catch ( Exception e )
		{
			e.printStackTrace();
			throw new DataExtractionServiceException(new Problem().code("unknownDataExtractionJob").message(e.getMessage()));
		}
		return startResult;
	}

	public class NFSDataExtractionExecutor extends DataExtractionThread
	{

		private final int containersCount;

		public NFSDataExtractionExecutor(final DataExtractionContext context, final String adapterHome, final int containersCount) throws DataExtractionServiceException
		{
			super(context);
			this.containersCount = containersCount;
		}

		@Override
		protected List<DataExtractionTask> runDataExtractionJob() throws Exception
		{
			final DataSource ds = this.context.ds;
			final DataExtractionSpec spec = this.context.spec;
			final DataExtractionJob job = this.context.job;

			return getDataExtractionTasks(ds, spec, job, containersCount);
		}

		private List<DataExtractionTask> getDataExtractionTasks(DataSource ds, DataExtractionSpec spec,

				DataExtractionJob job, int containersCount)

				throws DataExtractionServiceException
		{

			List<DataExtractionTask> dataExtractionJobTasks = new ArrayList<DataExtractionTask>();

			int objectsCount = 0;
			int tasksCount = 0;

			try
			{
				synchronized (job)
				{

					job.setOutputMessagingQueue("DES-" + job.getId());

					job.objectsExtracted(0);

					job.setTasksCount(tasksCount);

					job.setObjectCount(objectsCount);

				}

				List<FileMetaInfo> filesInfoList = new ArrayList<>();
				final boolean smbAuth = Boolean.parseBoolean(getConnectionParam(ds, PARAM_SMB_AUTHENTICATION_ID));
				final String pathName = getConnectionParam(ds, PARAM_FILE_ID);

				if( smbAuth )
				{
					SmbFile smbFile = getSmbFileSystem(ds);
					if( null != smbFile )
					{
						getSmbFilesList(ds, smbFile, pathName, filesInfoList);
					}
				}
				else
				{
					File file = getFileSystem(ds);
					if( null != file )
					{
						getFilesList(ds, file, pathName, filesInfoList);
					}
				}

				objectsCount = filesInfoList.size();

				for (int i = 0; i < filesInfoList.size(); i += 10)
				{
					List<FileMetaInfo> tmpFilesInfoList = new ArrayList<>(MAX_FILES_THRESHOLD);
					int start = i;
					int end = (i + 10);

					if( start >= objectsCount )
					{
						start = objectsCount;
					}
					if( end > objectsCount )
					{
						end = objectsCount;
					}

					tmpFilesInfoList = filesInfoList.subList(start, end);

					dataExtractionJobTasks.add(getDataExtractionTask(ds, spec, job, tmpFilesInfoList));
					tasksCount++;
				}
			}
			catch ( Exception e )
			{
				throw new DataExtractionServiceException(new Problem().code("unknownDataExtractionJob").message(e.getMessage()));
			}
			synchronized (job)
			{
				job.setTasksCount(tasksCount);
				job.setObjectCount(objectsCount);
			}

			return dataExtractionJobTasks;
		}

		private final DataExtractionTask getDataExtractionTask(DataSource ds, DataExtractionSpec spec,

				DataExtractionJob job, List<FileMetaInfo> filesInfoList) throws DataExtractionServiceException
		{
			DataExtractionTask dataExtractionTask = new DataExtractionTask();

			try
			{
				final String host = getConnectionParam(ds, PARAM_HOST_ID);
				final String shareName = getConnectionParam(ds, PARAM_SHARE_ID);
				final String user = getConnectionParam(ds, PARAM_USER_ID);
				final String password = getConnectionParam(ds, PARAM_PASSWORD_ID);
				final boolean smbAuth = Boolean.parseBoolean(getConnectionParam(ds, PARAM_SMB_AUTHENTICATION_ID));

				Map<String, String> contextParams = getContextParams(job.getOutputMessagingQueue(), host, shareName, user, password, smbAuth, filesInfoList, spec.getScope().name(), String.valueOf(spec.getSampleSize()));

				dataExtractionTask.taskId("DES-Task-" + getUUID())

						.jobId(job.getId())

						.typeId(TYPE_ID)

						.contextParameters(contextParams)

						.numberOfFailedAttempts(0);
			}
			catch ( Exception e )
			{
				throw new DataExtractionServiceException(new Problem().code("unknownDataExtractionJob").message(e.getMessage()));
			}
			return dataExtractionTask;
		}

		public Map<String, String> getContextParams(String jobId, String host, String shareName, String user, String password, boolean smbAuth, List<FileMetaInfo> filesInfoList, final String extractionScope, final String sampleSize) throws IOException
		{

			ObjectMapper mapperObj = new ObjectMapper();

			String filesInfo = mapperObj.writeValueAsString(filesInfoList);

			Map<String, String> ilParamsVals = new LinkedHashMap<>();

			ilParamsVals.put("JOB_STARTDATETIME", getConvertedDate(new Date()));

			ilParamsVals.put("HOST", host);

			ilParamsVals.put("SHARENAME", shareName);

			ilParamsVals.put("USERNAME", user);

			ilParamsVals.put("PASSWORD", password);

			ilParamsVals.put("SMBAUTH", String.valueOf(smbAuth));

			ilParamsVals.put("JOB_ID", jobId);

			ilParamsVals.put("SCOPE", extractionScope);

			ilParamsVals.put("SAMPLESIZE", sampleSize);

			ilParamsVals.put("FILES_INFO", filesInfo);

			ilParamsVals.put("DESTASKSTATUS", taskStatusQueueName);

			return ilParamsVals;

		}

	}

	private List<String> getSmbFilesList(DataSource ds, SmbFile smbFile, String filePath, List<FileMetaInfo> filesInfoList) throws DataExtractionServiceException, SmbException
	{
		List<String> docTypeList = Arrays.asList("doc", "docx", "xls", "xlsx", "ppt", "pptx", "odt", "ods", "odp", "txt", "rtf", "pdf");
		SmbFile[] listFiles = null;
		List<String> filesList = new ArrayList<>();
		if( smbFile != null )
		{
			if( smbFile.isDirectory() )
			{
				listFiles = smbFile.listFiles();
				for (SmbFile tmpFile : listFiles)
				{
					String fileExtension = FilenameUtils.getExtension(tmpFile.getName());
					if( fileExtension.length() > 0 && docTypeList.contains(fileExtension.toLowerCase()) )
					{
						FileMetaInfo fileMetaInfo = new FileMetaInfo().fileName(tmpFile.getName()).filePath(tmpFile.getPath()).fileSize(getFileSize(ds, tmpFile.getPath())).fileType(fileExtension);

						filesInfoList.add(fileMetaInfo);
					}
					else if( tmpFile.isDirectory() )
					{
						StringBuilder sb = new StringBuilder();
						sb.append(null != tmpFile.getPath() ? tmpFile.getPath() : "/").append(tmpFile.getName());
						getSmbFilesList(ds, tmpFile, sb.toString(), filesInfoList);
					}
				}
			}
		}
		return filesList;
	}

	private List<String> getFilesList(DataSource ds, File file, String filePath, List<FileMetaInfo> filesInfoList) throws DataExtractionServiceException
	{
		List<String> docTypeList = Arrays.asList("doc", "docx", "xls", "xlsx", "ppt", "pptx", "odt", "ods", "odp", "txt", "rtf", "pdf");
		File[] listFiles = null;
		List<String> filesList = new ArrayList<>();
		if( file != null )
		{
			if( file.isDirectory() && file.exists() )
			{
				listFiles = file.listFiles();
				for (File tmpFile : listFiles)
				{
					String fileExtension = FilenameUtils.getExtension(tmpFile.getName());
					if( !tmpFile.isDirectory() && fileExtension.length() > 0 && docTypeList.contains(fileExtension.toLowerCase()) )
					{
						FileMetaInfo fileMetaInfo = new FileMetaInfo().fileName(tmpFile.getName()).filePath(tmpFile.getPath()).fileSize(getFileSize(ds, tmpFile.getPath())).fileType(fileExtension);

						filesInfoList.add(fileMetaInfo);
					}
					else if( tmpFile.isDirectory() )
					{
						StringBuilder sb = new StringBuilder();
						sb.append(null != tmpFile.getPath() ? tmpFile.getPath() : "/").append(tmpFile.getName());
						getFilesList(ds, tmpFile, sb.toString(), filesInfoList);
					}
				}
			}
		}
		return filesList;
	}

	private int getFileSize(DataSource ds, String filePath) throws DataExtractionServiceException
	{
		final boolean smbAuth = Boolean.parseBoolean(getConnectionParam(ds, PARAM_SMB_AUTHENTICATION_ID));

		final String userName = getConnectionParam(ds, PARAM_USER_ID);
		final String password = getConnectionParam(ds, PARAM_PASSWORD_ID);

		String userNamePassword = userName + ":" + password;

		int fileSize = 0;
		SmbFile smbFile = null;
		File file = null;
		try
		{
			if( smbAuth )
			{
				smbFile = getSmbFileByPath(userNamePassword, filePath);
				fileSize = (int) smbFile.length();
			}
			else
			{
				file = getFile(filePath);
				fileSize = (int) file.length();
			}
		}
		catch ( IOException e )
		{
			throw new DataExtractionServiceException(new Problem().code("unknownFileSize").message(e.getMessage()));
		}
		catch ( Exception e )
		{
			throw new DataExtractionServiceException(new Problem().code("unknownFileSize").message(e.getMessage()));
		}
		return fileSize;
	}

	@Override
	public int getCountRows(DataSource paramDataSource, DataExtractionSpec paramDataExtractionSpec) throws DataExtractionServiceException
	{
		return 0;
	}

	@Override
	public Metadata getMetadata(DataSource ds) throws DataExtractionServiceException
	{
		Metadata metadata = getMetadataForUnstructuredDS(ds);
		return metadata;
	}

}
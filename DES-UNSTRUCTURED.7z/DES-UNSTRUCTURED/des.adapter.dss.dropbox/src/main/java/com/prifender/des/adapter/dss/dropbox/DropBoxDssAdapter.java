package com.prifender.des.adapter.dss.dropbox;

import static com.prifender.des.util.DatabaseUtil.createDir;
import static com.prifender.des.util.DatabaseUtil.getConvertedDate;
import static com.prifender.des.util.DatabaseUtil.getUUID;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.dropbox.core.DbxApiException;
import com.dropbox.core.DbxException;
import com.dropbox.core.DbxRequestConfig;
import com.dropbox.core.v2.DbxClientV2;
import com.dropbox.core.v2.DbxTeamClientV2;
import com.dropbox.core.v2.files.FileMetadata;
import com.dropbox.core.v2.files.ListFolderBuilder;
import com.dropbox.core.v2.files.ListFolderResult;
import com.dropbox.core.v2.team.GroupMemberInfo;
import com.dropbox.core.v2.team.GroupSelector;
import com.dropbox.core.v2.team.GroupsListResult;
import com.dropbox.core.v2.team.GroupsMembersListResult;
import com.dropbox.core.v2.team.MemberProfile;
import com.dropbox.core.v2.teamcommon.GroupSummary;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.prifender.des.DataExtractionServiceException;
import com.prifender.des.controller.DataExtractionContext;
import com.prifender.des.controller.DataExtractionThread;
import com.prifender.des.controller.DataSourceAdapter;
import com.prifender.des.model.ConnectionParamDef;
import com.prifender.des.model.ConnectionParamDef.TypeEnum;
import com.prifender.des.model.ConnectionStatus;
import com.prifender.des.model.DataExtractionJob;
import com.prifender.des.model.DataExtractionSpec;
import com.prifender.des.model.DataExtractionTask;
import com.prifender.des.model.DataSource;
import com.prifender.des.model.DataSourceType;
import com.prifender.des.model.FileMetaInfo;
import com.prifender.des.model.Metadata;
import com.prifender.des.model.Problem;

@Component
public class DropBoxDssAdapter extends DataSourceAdapter
{
	private static final int MAX_FILES_THRESHOLD = 10;

	// DropBox API Token
	public static final String PARAM_ACCESS_TOKEN_ID = "AccessToken";
	public static final String PARAM_ACCESS_TOKEN_LABEL = "Access Token";
	public static final String PARAM_ACCESS_TOKEN_DESCRIPTION = "AccessToken, which is required for authorization";

	public static final ConnectionParamDef PARAM_ACCESS_TOKEN = new ConnectionParamDef().id(PARAM_ACCESS_TOKEN_ID).label(PARAM_ACCESS_TOKEN_LABEL).description(PARAM_ACCESS_TOKEN_DESCRIPTION).type(TypeEnum.STRING);

	public static final String TYPE_ID = "Dropbox";
	public static final String TYPE_LABEL = "Dropbox";
	
	private static final DataSourceType TYPE = new DataSourceType().id(TYPE_ID).label(TYPE_LABEL).addConnectionParamsItem(PARAM_USER).addConnectionParamsItem(PARAM_ACCESS_TOKEN);

	@Override
	public DataSourceType getDataSourceType()
	{
		return TYPE;
	}

	@Override
	public ConnectionStatus testConnection(DataSource ds) throws DataExtractionServiceException
	{
		DbxTeamClientV2 teamClient = null;

		try
		{
			teamClient = getConnection(ds);
			if( teamClient != null )
			{
				final String userName = getConnectionParam(ds, PARAM_USER_ID);

				String memberId = getMemberId(teamClient, userName);

				if( null != memberId )
				{
					return new ConnectionStatus().code(ConnectionStatus.CodeEnum.SUCCESS).message("DropBox Authorization Successful.");
				}
			}
		}
		catch ( Exception e )
		{
			 
			return new ConnectionStatus().code(ConnectionStatus.CodeEnum.FAILURE).message(e.getMessage());
		}

		return new ConnectionStatus().code(ConnectionStatus.CodeEnum.FAILURE).message("DropBox Authorization Failed.");
	}

	private DbxTeamClientV2 getConnection(final DataSource ds)
	{
		final String accessToken = getConnectionParam(ds, PARAM_ACCESS_TOKEN_ID);
		DbxRequestConfig config = new DbxRequestConfig("Prefinder-Demo");
		return new DbxTeamClientV2(config, accessToken);
	}

	private String getMemberId(DbxTeamClientV2 teamClient, String accountName) throws DbxApiException, DbxException
	{
		GroupsListResult groups = teamClient.team().groupsList();
		List<GroupSummary> groupInfo = groups.getGroups();

		List<String> groupIds = new ArrayList<>();
		for (GroupSummary groupSummary : groupInfo)
		{
			groupIds.add(groupSummary.getGroupId());
		}

		for (String groupId : groupIds)
		{
			GroupSelector selector = GroupSelector.groupId(groupId);
			GroupsMembersListResult groupMems = teamClient.team().groupsMembersList(selector);

			List<GroupMemberInfo> memberInfoList = groupMems.getMembers();
			for (GroupMemberInfo memberInfo : memberInfoList)
			{
				MemberProfile memberProfile = memberInfo.getProfile();
				if( accountName.equals(memberProfile.getEmail()) )
				{
					return memberProfile.getTeamMemberId();
				}
			}
		}
		return null;
	}

	private DbxClientV2 getUserAccount(DbxTeamClientV2 teamClient, String memberId)
	{
		DbxClientV2 userClient = teamClient.asMember(memberId);
		return userClient;
	}

	@Override
	public Metadata getMetadata(final DataSource ds) throws DataExtractionServiceException
	{
		Metadata metadata = getMetadataForUnstructuredDS(ds);
		return metadata;
	}

	@Override
	public StartResult startDataExtractionJob(DataSource ds, DataExtractionSpec spec, final int containersCount) throws DataExtractionServiceException
	{
		StartResult startResult = null;
		try
		{
			final DataExtractionJob job = createDataExtractionJob(ds, spec);
			String adapterHome = createDir(this.desHome, TYPE_LABEL);
			final DataExtractionContext context = new DataExtractionContext(this, getDataSourceType(), ds, spec, job, this.messaging, this.pendingTasksQueue, this.pendingTasksQueueName, TYPE_LABEL, this.encryption);
			final DataExtractionThread dataExtractionExecutor = new DropboxDataExtractionExecutor(context, adapterHome, containersCount);
			this.threadPool.execute(dataExtractionExecutor);
			startResult = new StartResult(job, dataExtractionExecutor);
		}
		catch ( Exception exe )
		{
			throw new DataExtractionServiceException(new Problem().code("unknownDataExtractionJob").message(exe.getMessage()));

		}
		return startResult;
	}
	
	public class DropboxDataExtractionExecutor extends DataExtractionThread
	{
		private final int containersCount;

		public DropboxDataExtractionExecutor(final DataExtractionContext context, final String adapterHome, final int containersCount) throws DataExtractionServiceException
		{
			super(context);
			this.containersCount = containersCount;
		}

		@Override
		protected List<DataExtractionTask> runDataExtractionJob() throws Exception
		{
			final DataSource ds = this.context.ds;
			final DataExtractionSpec spec = this.context.spec;
			final DataExtractionJob job = this.context.job;

			return getDataExtractionTasks(ds, spec, job, containersCount);
		}

		private List<DataExtractionTask> getDataExtractionTasks(DataSource ds, DataExtractionSpec spec,

				DataExtractionJob job, int containersCount) throws DataExtractionServiceException
		{

			List<DataExtractionTask> dataExtractionJobTasks = new ArrayList<DataExtractionTask>();

			int objectsCount = 0;
			int tasksCount = 0;

			try
			{
				synchronized (job)
				{

					job.setOutputMessagingQueue("DES-" + job.getId());

					job.objectsExtracted(0);

					job.setTasksCount(tasksCount);

					job.setObjectCount(objectsCount);

				}

				Map<String, Object> infoMap = getFilesInfoMap(ds);
				String memberId = (String) infoMap.get("memberId");
				@SuppressWarnings("unchecked")
				List<FileMetaInfo> filesInfoList = (List<FileMetaInfo>) infoMap.get("filesInfoList");

				objectsCount = filesInfoList.size();

				for (int i = 0; i < filesInfoList.size(); i += 10)
				{
					List<FileMetaInfo> tmpFilesInfoList = new ArrayList<>(MAX_FILES_THRESHOLD);
					int start = i;
					int end = (i + 10);

					if( start >= objectsCount )
					{
						start = objectsCount;
					}
					if( end > objectsCount )
					{
						end = objectsCount;
					}

					tmpFilesInfoList = filesInfoList.subList(start, end);

					dataExtractionJobTasks.add(getDataExtractionTask(ds, spec, job, memberId, tmpFilesInfoList));
					tasksCount++;
				}
			}
			catch ( Exception e )
			{
				throw new DataExtractionServiceException(new Problem().code("unknownDataExtractionJob").message(e.getMessage()));
			}
			synchronized (job)
			{
				job.setTasksCount(tasksCount);
				job.setObjectCount(objectsCount);
			}

			return dataExtractionJobTasks;
		}

		private final DataExtractionTask getDataExtractionTask(DataSource ds, DataExtractionSpec spec,

				DataExtractionJob job, String memberId, List<FileMetaInfo> filesInfoList) throws DataExtractionServiceException
		{

			DataExtractionTask dataExtractionTask = new DataExtractionTask();

			try
			{

				final String userName = getConnectionParam(ds, PARAM_USER_ID);
				final String accessToken = getConnectionParam(ds, PARAM_ACCESS_TOKEN_ID);

				Map<String, String> contextParams = getContextParams(job.getOutputMessagingQueue(), userName, memberId, accessToken, filesInfoList, spec.getScope().name(), String.valueOf(spec.getSampleSize()));

				dataExtractionTask.taskId("DES-Task-" + getUUID())

						.jobId(job.getId())

						.typeId(TYPE_ID)

						.contextParameters(contextParams)

						.numberOfFailedAttempts(0);
			}
			catch ( Exception e )
			{
				throw new DataExtractionServiceException(new Problem().code("unknownDataExtractionJob").message(e.getMessage()));
			}
			return dataExtractionTask;
		}

		private Map<String, String> getContextParams(String jobId, String userName, String memberId, String accessToken, List<FileMetaInfo> filesInfoList, final String extractionScope, final String sampleSize) throws IOException
		{

			ObjectMapper mapperObj = new ObjectMapper();
			
			String filesInfo = mapperObj.writeValueAsString(filesInfoList);

			Map<String, String> ilParamsVals = new LinkedHashMap<>();

			ilParamsVals.put("JOB_STARTDATETIME", getConvertedDate(new Date()));

			ilParamsVals.put("USER_NAME", userName);

			ilParamsVals.put("MEMBER_ID", memberId);

			ilParamsVals.put("ACCESS_TOKEN", accessToken);

			ilParamsVals.put("FILES_INFO", filesInfo);

			ilParamsVals.put("SCOPE", extractionScope);

			ilParamsVals.put("SAMPLESIZE", sampleSize);

			return ilParamsVals;

		}
		
		private Map<String, Object> getFilesInfoMap(final DataSource ds) throws DataExtractionServiceException
		{
			Map<String, Object> infoMap = new HashMap<>();

			List<FileMetaInfo> filesInfoList = new ArrayList<>();
			try
			{
				String[] fileTypes = new String[] { "doc", "docx", "xls", "xlsx", "ppt", "pptx", "odt", "ods", "odp", "txt", "rtf", "pdf" };

				List<String> reqDocTypeList = new ArrayList<String>(Arrays.asList(fileTypes));

				DbxTeamClientV2 teamClient = getConnection(ds);
				if( teamClient != null )
				{
					final String userName = getConnectionParam(ds, PARAM_USER_ID);

					String memberId = getMemberId(teamClient, userName);
					infoMap.put("memberId", memberId);
					DbxClientV2 userClient = getUserAccount(teamClient, memberId);

					if( null != userClient )
					{
						ListFolderBuilder listFolderBuilder = userClient.files().listFolderBuilder("");
						ListFolderResult result = listFolderBuilder.withRecursive(true).start();
	 
						while (true)
						{
							for (com.dropbox.core.v2.files.Metadata metadata : result.getEntries())
							{
								if( metadata instanceof FileMetadata )
								{

									String fileExtension = "";

									if( null != metadata && null != metadata.getName() )
									{
										fileExtension = metadata.getName().substring(metadata.getName().lastIndexOf(".") + 1);
									}

									if( null != metadata && reqDocTypeList.contains(fileExtension) )
									{
										FileMetaInfo fileMetaInfo = new FileMetaInfo().fileId(((FileMetadata) metadata).getId()).fileName(metadata.getName()).filePath(metadata.getPathDisplay()).fileExtension(fileExtension).fileSize((int) ((FileMetadata) metadata).getSize())
												.fileType(fileExtension.toUpperCase());

										filesInfoList.add(fileMetaInfo);
									}
								}
							}
							if( !result.getHasMore() )
							{
								break;
							}
							result = userClient.files().listFolderContinue(result.getCursor());
						}
					}
				}
			}
			catch ( DbxException e )
			{
				throw new DataExtractionServiceException(new Problem().code("unknownConnection").message(e.getMessage()));
			}
			infoMap.put("filesInfoList", filesInfoList);
			return infoMap;
		}
	}

	@Override
	public int getCountRows(DataSource ds, DataExtractionSpec spec) throws DataExtractionServiceException {
		return 0;
	}

}
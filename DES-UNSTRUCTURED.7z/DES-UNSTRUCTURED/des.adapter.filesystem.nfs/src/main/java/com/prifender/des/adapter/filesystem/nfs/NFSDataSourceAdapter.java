package com.prifender.des.adapter.filesystem.nfs;

import static com.prifender.des.util.DatabaseUtil.createDir;
import static com.prifender.des.util.DatabaseUtil.getConvertedDate;
import static com.prifender.des.util.DatabaseUtil.getUUID;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.prifender.des.DataExtractionServiceException;
import com.prifender.des.controller.DataExtractionContext;
import com.prifender.des.controller.DataExtractionThread;
import com.prifender.des.controller.DataSourceAdapter;
import com.prifender.des.model.ConnectionParamDef;
import com.prifender.des.model.ConnectionParamDef.TypeEnum;
import com.prifender.des.model.ConnectionStatus;
import com.prifender.des.model.DataExtractionJob;
import com.prifender.des.model.DataExtractionSpec;
import com.prifender.des.model.DataExtractionTask;
import com.prifender.des.model.DataSource;
import com.prifender.des.model.DataSourceType;
import com.prifender.des.model.FileMetaInfo;
import com.prifender.des.model.Metadata;
import com.prifender.des.model.Problem;
import com.sun.xfile.XFile;

@Component
public class NFSDataSourceAdapter extends DataSourceAdapter
{

	private static final int MAX_FILES_THRESHOLD = 10;

	@Value("${des.home}")
	private String desHome;

	@Value("${scheduling.taskStatusQueue}")
	private String taskStatusQueueName;

	public static final String TYPE_ID = "NFS";
	public static final String TYPE_LABEL = "NFS";

	// File
	public static final String PARAM_FILE_ID = "FilePath";
	public static final String PARAM_FILE_LABEL = "FilePath";
	public static final String PARAM_FILE_DESCRIPTION = "The path of the file";

	public static final ConnectionParamDef PARAM_FILE = new ConnectionParamDef().id(PARAM_FILE_ID).label(PARAM_FILE_LABEL).description(PARAM_FILE_DESCRIPTION).type(TypeEnum.STRING).required(false);

	// ShareName
	public static final String PARAM_SHARE_ID = "Share";
	public static final String PARAM_SHARE_LABEL = "Share";
	public static final String PARAM_SHARE_DESCRIPTION = "The File Share Name";

	public static final ConnectionParamDef PARAM_SHARE = new ConnectionParamDef().id(PARAM_SHARE_ID).label(PARAM_SHARE_LABEL).description(PARAM_SHARE_DESCRIPTION).type(TypeEnum.STRING);

	private static final DataSourceType TYPE = new DataSourceType().id(TYPE_ID).label(TYPE_LABEL)
			.addConnectionParamsItem(PARAM_HOST)
			.addConnectionParamsItem(PARAM_SHARE)
			.addConnectionParamsItem(PARAM_FILE);

	@Override
	public DataSourceType getDataSourceType()
	{
		return TYPE;
	}

	@Override
	public ConnectionStatus testConnection(DataSource ds) throws DataExtractionServiceException
	{
		XFile xFile = null;
		try
		{
			xFile = getNfsFileSystem(ds);
			if( xFile != null && xFile.exists() )
			{
				/*final String host = getConnectionParam(ds, PARAM_HOST_ID);
				final String shareName = getConnectionParam(ds, PARAM_SHARE_ID);
				final String pathName = getConnectionParam(ds, PARAM_FILE_ID);
				List<FileMetaInfo> filesInfoList = new ArrayList<>();
				getNfsFilesList(xFile, host, shareName, pathName, filesInfoList);*/
				return new ConnectionStatus().code(ConnectionStatus.CodeEnum.SUCCESS).message("NFS File System connection successfully established.");
			}
		}
		catch ( Exception e )
		{
			return new ConnectionStatus().code(ConnectionStatus.CodeEnum.FAILURE).message(e.getMessage());
		}
		return new ConnectionStatus().code(ConnectionStatus.CodeEnum.FAILURE).message("Could not connect to NFS File System.");
	}
	
	private XFile getNfsFileSystem(DataSource ds) throws DataExtractionServiceException
	{
		XFile xfile = null;
		try
		{
			if( ds == null )
			{
				throw new DataExtractionServiceException(new Problem().code("unknownDataSource").message("datasource is null"));
			}
			final String filePath = getConnectionParam(ds, PARAM_FILE_ID);
			final String host = getConnectionParam(ds, PARAM_HOST_ID);
			final String shareName = getConnectionParam(ds, PARAM_SHARE_ID);

			if( shareName.startsWith("/") && shareName.endsWith("/") )
			{
				if( StringUtils.isNotBlank(host) && StringUtils.isNotBlank(shareName) )
				{
					xfile = getNfsFile(host, shareName, filePath);
				}
			}
			else
			{
				throw new DataExtractionServiceException(new Problem().code("unknownFile").message("share '" + shareName + "' path should start and end with '/'"));
			}

		}
		catch ( MalformedURLException e )
		{
			throw new DataExtractionServiceException(new Problem().code("unknownFile").message(e.getMessage()));
		}
		catch ( Exception e )
		{
			throw new DataExtractionServiceException(new Problem().code("unknownFile").message(e.getMessage()));
		}
		return xfile;
	}

	private XFile getNfsFile(String host, String shareName, String filePath) throws MalformedURLException, DataExtractionServiceException
	{
		if( shareName.startsWith("/") && shareName.endsWith("/") )
		{
			String path = "nfs://" + host + shareName;

			if(null != filePath)
			{
				path += filePath;
			}
			XFile xfile = new XFile(path);
			if( xfile.exists() )
			{
				return xfile;
			}
			else
			{
				return null;
			}
		}
		else
		{
			throw new DataExtractionServiceException(new Problem().code("unknownFile").message("share '" + shareName + "' path should start and end with '/'"));
		}
	}
	
	@Override
	public Metadata getMetadata(DataSource ds) throws DataExtractionServiceException
	{
		Metadata metadata = getMetadataForUnstructuredDS(ds);
		return metadata;
	}

	@Override
	public StartResult startDataExtractionJob(DataSource ds, DataExtractionSpec spec, final int containersCount) throws DataExtractionServiceException
	{
		StartResult startResult = null;
		try
		{
			final DataExtractionJob job = createDataExtractionJob(ds, spec);
			String adapterHome = createDir(this.desHome, TYPE_LABEL);
			final DataExtractionContext context = new DataExtractionContext(this, getDataSourceType(), ds, spec, job, this.messaging, this.pendingTasksQueue, this.pendingTasksQueueName, TYPE_LABEL, this.encryption);
			final DataExtractionThread dataExtractionExecutor = new NFSDataExtractionExecutor(context, adapterHome, containersCount);
			this.threadPool.execute(dataExtractionExecutor);
			startResult = new StartResult(job, dataExtractionExecutor);
		}
		catch ( Exception e )
		{
			e.printStackTrace();
			throw new DataExtractionServiceException(new Problem().code("unknownDataExtractionJob").message(e.getMessage()));
		}
		return startResult;
	}

	public class NFSDataExtractionExecutor extends DataExtractionThread
	{

		private final int containersCount;

		public NFSDataExtractionExecutor(final DataExtractionContext context, final String adapterHome, final int containersCount) throws DataExtractionServiceException
		{
			super(context);
			this.containersCount = containersCount;
		}

		@Override
		protected List<DataExtractionTask> runDataExtractionJob() throws Exception
		{
			final DataSource ds = this.context.ds;
			final DataExtractionSpec spec = this.context.spec;
			final DataExtractionJob job = this.context.job;

			return getDataExtractionTasks(ds, spec, job, containersCount);
		}
		
		private List<DataExtractionTask> getDataExtractionTasks(DataSource ds, DataExtractionSpec spec,

				DataExtractionJob job, int containersCount)

						throws DataExtractionServiceException
		{

			List<DataExtractionTask> dataExtractionJobTasks = new ArrayList<DataExtractionTask>();

			int objectsCount = 0;
			int tasksCount = 0;

			try
			{
				synchronized (job)
				{

					job.setOutputMessagingQueue("DES-" + job.getId());

					job.objectsExtracted(0);

					job.setTasksCount(tasksCount);

					job.setObjectCount(objectsCount);

				}

				List<FileMetaInfo> filesInfoList = new ArrayList<>();
				getFilesList(ds, filesInfoList);

				objectsCount = filesInfoList.size();

				for (int i = 0; i < filesInfoList.size(); i += 10)
				{
					List<FileMetaInfo> tmpFilesInfoList = new ArrayList<>(MAX_FILES_THRESHOLD);
					int start = i;
					int end = (i + 10);

					if( start >= objectsCount )
					{
						start = objectsCount;
					}
					if( end > objectsCount )
					{
						end = objectsCount;
					}

					tmpFilesInfoList = filesInfoList.subList(start, end);

					dataExtractionJobTasks.add(getDataExtractionTask(ds, spec, job, tmpFilesInfoList));
					tasksCount++;
				}
			}
			catch ( Exception e )
			{
				throw new DataExtractionServiceException(new Problem().code("unknownDataExtractionJob").message(e.getMessage()));
			}
			synchronized (job)
			{
				job.setTasksCount(tasksCount);
				job.setObjectCount(objectsCount);
			}

			return dataExtractionJobTasks;
		}

		private final DataExtractionTask getDataExtractionTask(DataSource ds, DataExtractionSpec spec,

				DataExtractionJob job, List<FileMetaInfo> filesInfoList) throws DataExtractionServiceException
		{
			DataExtractionTask dataExtractionTask = new DataExtractionTask();

			try
			{
				final String host = getConnectionParam(ds, PARAM_HOST_ID);
				final String shareName = getConnectionParam(ds, PARAM_SHARE_ID);
				
				Map<String, String> contextParams = getContextParams(job.getOutputMessagingQueue(), host, shareName, filesInfoList, spec.getScope().name(), String.valueOf(spec.getSampleSize()));

				dataExtractionTask.taskId("DES-Task-" + getUUID())

						.jobId(job.getId())

						.typeId(TYPE_ID)

						.contextParameters(contextParams)

						.numberOfFailedAttempts(0);
			}
			catch ( Exception e )
			{
				throw new DataExtractionServiceException(new Problem().code("unknownDataExtractionJob").message(e.getMessage()));
			}
			return dataExtractionTask;
		}

		public Map<String, String> getContextParams( String jobId, String host, String shareName, List<FileMetaInfo> filesInfoList, 
														final String extractionScope, final String sampleSize) throws IOException
		{
			
			ObjectMapper mapperObj = new ObjectMapper();
			
			String filesInfo = mapperObj.writeValueAsString(filesInfoList);

			Map<String, String> ilParamsVals = new LinkedHashMap<>();

			ilParamsVals.put("JOB_STARTDATETIME", getConvertedDate(new Date()));

			ilParamsVals.put("HOST", host);

			ilParamsVals.put("SHARENAME", shareName);

			ilParamsVals.put("JOB_ID", jobId);

			ilParamsVals.put("SCOPE", extractionScope);

			ilParamsVals.put("SAMPLESIZE", sampleSize);
			
			ilParamsVals.put("FILES_INFO", filesInfo);

			ilParamsVals.put("DESTASKSTATUS", taskStatusQueueName);

			return ilParamsVals;

		}

	}

	private void getFilesList(DataSource ds, List<FileMetaInfo> filesInfoList) throws DataExtractionServiceException, FileNotFoundException, IOException
	{
		final String host = getConnectionParam(ds, PARAM_HOST_ID);
		final String shareName = getConnectionParam(ds, PARAM_SHARE_ID);
		final String pathName = getConnectionParam(ds, PARAM_FILE_ID);
	
		XFile xFile = getNfsFileSystem(ds);
		
		getNfsFilesList(xFile, host, shareName, pathName, filesInfoList);
	}
	
	private void getNfsFilesList(XFile xfile, String host, String shareName, String pathName, List<FileMetaInfo> filesInfoList) throws FileNotFoundException, IOException, DataExtractionServiceException
	{
		List<String> docTypeList = Arrays.asList("doc", "docx", "xls", "xlsx", "ppt", "pptx", "odt", "ods", "odp", "txt", "rtf", "pdf");
		String[] listFiles = null;
		if( xfile != null )
		{
			if( xfile.exists() && xfile.isDirectory() )
			{
				listFiles = xfile.list();
				for (String fileName : listFiles)
				{
					String fileExtension = FilenameUtils.getExtension(fileName);
					if(fileExtension.length() > 0 && docTypeList.contains(fileExtension.toLowerCase()))
					{
						StringBuilder sb = new StringBuilder();
						sb.append(host).append(shareName).append(null != pathName ? pathName : "/").append(fileName);
						String filePath = sb.toString();
						FileMetaInfo fileMetaInfo = new FileMetaInfo().fileName(fileName).filePath(filePath).fileSize(getFileSize(filePath)).fileType(fileExtension);
						
						filesInfoList.add(fileMetaInfo);
					} 
					else
					{
						StringBuilder sb = new StringBuilder();
						sb.append(null != pathName ? pathName + "/" : "/").append(fileName);
						xfile = getNfsFile(host, shareName, sb.toString());
						if(null != xfile)
						{
							getNfsFilesList(xfile, host, shareName, sb.toString(), filesInfoList);
						}
					}
				}
			}
		}
	}

	private int getFileSize(String fileName) throws DataExtractionServiceException
	{
		int fileSize = 0;
		XFile xfile = null;
		try
		{
			xfile = getNfsFileByPath(fileName);
			fileSize = (int) xfile.length();
		}
		catch ( IOException e )
		{
			throw new DataExtractionServiceException(new Problem().code("unknownFileSize").message(e.getMessage()));
		}
		catch ( Exception e )
		{
			throw new DataExtractionServiceException(new Problem().code("unknownFileSize").message(e.getMessage()));
		}
		return fileSize;
	}

	private XFile getNfsFileByPath(String fileName) throws MalformedURLException
	{
		String path = "nfs://" + fileName;
		XFile xfile = new XFile(path);
		if( xfile.exists() )
		{
			return xfile;
		}
		else
		{
			return null;
		}
	}
	
	@Override
	public int getCountRows(DataSource paramDataSource, DataExtractionSpec paramDataExtractionSpec)
			throws DataExtractionServiceException {
		return 0;
	}
	
}
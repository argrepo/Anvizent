package com.prifender.des.adapter.dss.imap;

import static com.prifender.des.util.DatabaseUtil.createDir;
import static com.prifender.des.util.DatabaseUtil.getConvertedDate;
import static com.prifender.des.util.DatabaseUtil.getUUID;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import javax.mail.Folder;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;

import org.springframework.stereotype.Component;
import com.prifender.des.DataExtractionServiceException;
import com.prifender.des.controller.DataExtractionContext;
import com.prifender.des.controller.DataExtractionThread;
import com.prifender.des.controller.DataSourceAdapter;
import com.prifender.des.model.ConnectionParamDef;
import com.prifender.des.model.ConnectionParamDef.TypeEnum;
import com.prifender.des.model.ConnectionStatus;
import com.prifender.des.model.DataExtractionJob;
import com.prifender.des.model.DataExtractionSpec;
import com.prifender.des.model.DataExtractionTask;
import com.prifender.des.model.DataSource;
import com.prifender.des.model.DataSourceType;
import com.prifender.des.model.FileMetaInfo;
import com.prifender.des.model.Metadata;
import com.prifender.des.model.Problem;

@Component
public class IMAPDssAdapter extends DataSourceAdapter
{
 
   //   Protocol
	public static final String PARAM_PROTOCAL_ID = "Protocol";
	public static final String PARAM_PROTOCAL_LABEL = "Protocol";
	public static final String PARAM_PROTOCAL_DESCRIPTION = "The name of protocol for IMAP";

	public static final ConnectionParamDef PARAM_PROTOCAL = new ConnectionParamDef().id(PARAM_PROTOCAL_ID).label(PARAM_PROTOCAL_LABEL).description(PARAM_PROTOCAL_DESCRIPTION).type(TypeEnum.STRING);

	// Folder Type
	public static final String PARAM_FOLDER_TYPE_ID = "Folder";
	public static final String PARAM_FOLDER_TYPE_LABEL = "Folder Type";
	public static final String PARAM_FOLDER_TYPE_DESCRIPTION = "Folder Type for IMAP";

	public static final ConnectionParamDef PARAM_FOLDER_TYPE = new ConnectionParamDef().id(PARAM_FOLDER_TYPE_ID).label(PARAM_FOLDER_TYPE_LABEL).description(PARAM_FOLDER_TYPE_DESCRIPTION).type(TypeEnum.STRING).required(false);

	public static final String TYPE_ID = "IMAP";
	public static final String TYPE_LABEL = "IMAP";

	private static final DataSourceType TYPE = new DataSourceType().id(TYPE_ID).label(TYPE_LABEL).addConnectionParamsItem(PARAM_USER).addConnectionParamsItem(PARAM_PASSWORD).addConnectionParamsItem(PARAM_HOST).addConnectionParamsItem(PARAM_PORT)
			.addConnectionParamsItem(PARAM_PROTOCAL).addConnectionParamsItem(PARAM_FOLDER_TYPE);

	List<FileMetaInfo> subFolderList = new ArrayList<FileMetaInfo>();

	@Override
	public DataSourceType getDataSourceType()
	{
		return TYPE;
	}

	@Override
	public ConnectionStatus testConnection(DataSource ds) throws DataExtractionServiceException
	{
		Session session = null;
		Store store = null;
		Folder[] folderArray = null;
		Folder folder = null;
		try
		{
			String protocol  = getConnectionParam(ds, PARAM_PROTOCAL_ID);
			session = getSesstion(ds, protocol);
			store = getStore(ds, session, protocol);
			final String folderType = getConnectionParam(ds, PARAM_FOLDER_TYPE_ID);
			if( folderType == null )
			{
				folderArray = getFolderList(store, ds);
				if( session != null && store != null && (folderArray != null && folderArray.length > 0) )
				{
					return new ConnectionStatus().code(ConnectionStatus.CodeEnum.SUCCESS).message("IMAP Authorization Successful.");
				}
			}
			else
			{
				folder = getFolder(store, ds);
				if( session != null && store != null && folder != null )
				{
					return new ConnectionStatus().code(ConnectionStatus.CodeEnum.SUCCESS).message("IMAP Authorization Successful.");
				}
			}

		}
		catch ( IllegalArgumentException e )
		{
			return new ConnectionStatus().code(ConnectionStatus.CodeEnum.FAILURE).message(e.getMessage());
		}
		catch ( MessagingException me )
		{
			return new ConnectionStatus().code(ConnectionStatus.CodeEnum.FAILURE).message(me.getMessage());
		}
		catch ( Exception e )
		{
			return new ConnectionStatus().code(ConnectionStatus.CodeEnum.FAILURE).message(e.getMessage());
		}
		finally
		{
			logout(session, store, folder, folderArray);
		}

		return new ConnectionStatus().code(ConnectionStatus.CodeEnum.FAILURE).message("IMAP Authorization Failed.");
	}

	/**
	 * to logout from the mail host server
	 * 
	 */
	public void logout(Session session, Store store, Folder folder, Folder[] folderArray)
	{
		try
		{
			if( folder != null )
			{
				folder.close(false);
			}
			/*
			 * if( folderArray != null ) { for (Folder f : folderArray) {
			 * f.close(false); } }
			 */
			if( store != null )
			{
				store.close();
				store = null;
			}
			if( session != null )
			{
				session = null;
			}
		}
		catch ( MessagingException e )
		{
			e.printStackTrace();
		}
	}

	private Session getSesstion(DataSource ds, String protocol)
	{

		if( ds == null )
		{
			throw new IllegalArgumentException("datasource is null.");
		}

		final String port = getConnectionParam(ds, PARAM_PORT_ID);
		final String host = getConnectionParam(ds, PARAM_HOST_ID);
		Properties properties = getServerProperties(protocol, host, port, false);
		return Session.getDefaultInstance(properties);

	}

	private Store getStore(DataSource ds, Session session, String protocol) throws MessagingException
	{
		final String userName = getConnectionParam(ds, PARAM_USER_ID);
		final String password = getConnectionParam(ds, PARAM_PASSWORD_ID);
		Store store = session.getStore(protocol);
		store.connect(userName, password);
		return store;
	}

	private Folder getFolder(Store store, DataSource ds) throws MessagingException
	{
		final String folderType =  getConnectionParam(ds, PARAM_FOLDER_TYPE_ID);
		Folder folder = store.getFolder(folderType);
		folder.open(Folder.READ_ONLY);
		return folder;
	}

	private Folder[] getFolderList(Store store, DataSource ds) throws MessagingException
	{
		Folder[] folderArray = store.getDefaultFolder().list();
		return folderArray;
	}

	private Properties getServerProperties(String protocol, String host, String port, boolean isSecured)
	{
		Properties properties = new Properties();
		properties.put(String.format("mail.%s.host", protocol), host);
		properties.put(String.format("mail.%s.port", protocol), port);
		properties.setProperty(String.format("mail.%s.socketFactory.class", protocol), isSecured ? "javax.net.ssl.SSLSocketFactory" : "javax.net.DefaultSocketFactory");
		properties.setProperty(String.format("mail.%s.socketFactory.fallback", protocol), "false");
		properties.setProperty(String.format("mail.%s.socketFactory.port", protocol), String.valueOf(port));
		return properties;
	}

	@Override
	public Metadata getMetadata(final DataSource ds) throws DataExtractionServiceException
	{
		Metadata metadata = getMetadataForUnstructuredDS(ds);
		return metadata;
	}

	@Override
	public StartResult startDataExtractionJob(DataSource ds, DataExtractionSpec spec, final int containersCount) throws DataExtractionServiceException
	{
		StartResult startResult = null;
		try
		{
			final DataExtractionJob job = createDataExtractionJob(ds, spec);
			String adapterHome = createDir(this.desHome, getDataSourceType().getId());
			final DataExtractionContext context = new DataExtractionContext(this, getDataSourceType(), ds, spec, job, this.messaging, this.pendingTasksQueue, this.pendingTasksQueueName, TYPE_LABEL, this.encryption);
			final DataExtractionThread dataExtractionExecutor = new IMAPDataExtractionExecutor(context, adapterHome, containersCount);
			this.threadPool.execute(dataExtractionExecutor);
			startResult = new StartResult(job, dataExtractionExecutor);
		}
		catch ( Exception exe )
		{
			throw new DataExtractionServiceException(new Problem().code("unknownDataExtractionJob").message(exe.getMessage()));

		}
		return startResult;
	}

	public class IMAPDataExtractionExecutor extends DataExtractionThread
	{
		private final int containersCount;

		public IMAPDataExtractionExecutor(final DataExtractionContext context, final String adapterHome, final int containersCount) throws DataExtractionServiceException
		{
			super(context);
			this.containersCount = containersCount;
		}

		@Override
		protected List<DataExtractionTask> runDataExtractionJob() throws Exception
		{
			final DataSource ds = this.context.ds;
			final DataExtractionSpec spec = this.context.spec;
			final DataExtractionJob job = this.context.job;

			return getDataExtractionTasks(ds, spec, job, containersCount);
		}

		private List<DataExtractionTask> getDataExtractionTasks(DataSource ds, DataExtractionSpec spec,

				DataExtractionJob job, int containersCount) throws DataExtractionServiceException
		{

			List<DataExtractionTask> dataExtractionJobTasks = new ArrayList<DataExtractionTask>();

			int objectsCount = 0;
			int tasksCount = 0;

			try
			{
				synchronized (job)
				{

					job.setOutputMessagingQueue("DES-" + job.getId());

					job.objectsExtracted(0);

					job.setTasksCount(tasksCount);

					job.setObjectCount(objectsCount);

				}

				List<FileMetaInfo> fileMetaInfoList = getFilesInfoList(ds);

				for (FileMetaInfo fileMetaInfo : fileMetaInfoList)
				{
					if( fileMetaInfo.getFileSize() != 0 )
					{
						dataExtractionJobTasks.add(getDataExtractionTask(ds, spec, job, fileMetaInfo));
						tasksCount++;
						if( "SAMPLE".equals(spec.getScope().name()) )
						{
							objectsCount += fileMetaInfo.getFileSize() < spec.getSampleSize() ? fileMetaInfo.getFileSize() : spec.getSampleSize();
						}
						else
						{
							objectsCount += fileMetaInfo.getFileSize();
						}
					}

				}
			}
			catch ( Exception e )
			{
				throw new DataExtractionServiceException(new Problem().code("unknownDataExtractionJob").message(e.getMessage()));
			}
			synchronized (job)
			{
				job.setTasksCount(tasksCount);
				job.setObjectCount(objectsCount);
			}

			return dataExtractionJobTasks;
		}

		private final DataExtractionTask getDataExtractionTask(DataSource ds, DataExtractionSpec spec,

				DataExtractionJob job, FileMetaInfo fileMetaInfo) throws DataExtractionServiceException
		{

			DataExtractionTask dataExtractionTask = new DataExtractionTask();

			try
			{
				final String userName = getConnectionParam(ds, PARAM_USER_ID);
				final String password = getConnectionParam(ds, PARAM_PASSWORD_ID);
				final String port = getConnectionParam(ds, PARAM_PORT_ID);
				final String host = getConnectionParam(ds, PARAM_HOST_ID);
				String protocol  = getConnectionParam(ds, PARAM_PROTOCAL_ID);

				Map<String, String> contextParams = getContextParams(job.getId(), userName, password, protocol ,port, host, "false",

						fileMetaInfo, String.valueOf(spec.getScope().name()), String.valueOf(spec.getSampleSize()));

				dataExtractionTask.taskId("DES-Task-" + getUUID())

						.jobId(job.getId())

						.typeId(TYPE_ID)

						.contextParameters(contextParams)

						.numberOfFailedAttempts(0);
			}
			catch ( Exception e )
			{
				throw new DataExtractionServiceException(new Problem().code("unknownDataExtractionJob").message(e.getMessage()));
			}
			return dataExtractionTask;
		}

		private Map<String, String> getContextParams(String jobId, String userName, String password,String protocal,

				String port, String hostName, String secured, FileMetaInfo fileMetaInfo, String scope, String sampleSize) throws IOException
		{

			Map<String, String> contextParams = new LinkedHashMap<>();

			contextParams.put("JOB_STARTDATETIME", getConvertedDate(new Date()));

			contextParams.put("DATASOURCE_USER", userName);

			contextParams.put("DATASOURCE_PORT", port);

			contextParams.put("DATASOURCE_HOST", hostName);

			contextParams.put("DATASOURCE_PASS", password);
			
			contextParams.put("DATASOURCE_PROTOCAL", protocal);

			contextParams.put("DATASOURCE_SSL_AUTH", secured);

			contextParams.put("FOLDER_TYPE", fileMetaInfo.getFileName());

			contextParams.put("SCOPE", scope);

			contextParams.put("SAMPLESIZE", sampleSize);

			contextParams.put("JOB_ID", jobId);

			return contextParams;

		}

		List<FileMetaInfo> getFilesInfoList(DataSource ds) throws MessagingException
		{
			Session session = null;
			Store store = null;
			Folder fd = null;
			Folder[] folderArray = null;
			List<FileMetaInfo> fileMetaInfoList = new ArrayList<>();
			try
			{
				String protocol = "imap";
				session = getSesstion(ds, protocol);
				store = getStore(ds, session, protocol);
				if( session != null && store != null )
				{
					final String folderType = getConnectionParam(ds, PARAM_FOLDER_TYPE_ID);
					if( folderType == null )
					{
						folderArray = store.getDefaultFolder().list();
						for (Folder folder : folderArray)
						{
							FileMetaInfo fileMetaInfo = new FileMetaInfo();
							fileMetaInfo.fileName(folder.getName());
							fileMetaInfo.setFileSize(folder.getMessageCount());
							fileMetaInfoList.add(fileMetaInfo);

							Folder[] fdArray = folder.list();

							if( fdArray.length > 0 && fdArray != null )
							{
								for (Folder folderName : fdArray)
								{
									fileMetaInfoList.addAll(getSubFolderList(folderName));
									subFolderList.clear();
								}
							}
						}
					}
					else
					{
						fd = store.getFolder( folderType );
						fd.open(Folder.READ_WRITE);

						FileMetaInfo fileMetaInfo = new FileMetaInfo();
						fileMetaInfo.fileName(fd.getFullName());
						fileMetaInfo.setFileSize(fd.getMessageCount());
						fileMetaInfoList.add(fileMetaInfo);

						Folder[] fdArray = fd.list();

						if( fdArray.length > 0 && fdArray != null )
						{
							for (Folder folderName : fdArray)
							{
								fileMetaInfoList.addAll(getSubFolderList(folderName));
								subFolderList.clear();
							}
						}

					}
				}
			}
			finally

			{
				logout(session, store, fd, folderArray);
			}
			return fileMetaInfoList;
		}

	}

	List<FileMetaInfo> getSubFolderList(Folder folder) throws MessagingException
	{
		FileMetaInfo fileMetaInfo = new FileMetaInfo();
		fileMetaInfo.fileName(folder.getFullName());
		fileMetaInfo.setFileSize(folder.getMessageCount());
		subFolderList.add(fileMetaInfo);

		Folder[] subFolderArray = folder.list();

		if( subFolderArray.length > 0 && subFolderArray != null )
		{
			for (Folder subSubFolder : subFolderArray)
			{
				if( subSubFolder != null )
				{
					getSubFolderList(subSubFolder);
				}
			}
		}

		return subFolderList;
	}

	@Override
	public int getCountRows(DataSource ds, DataExtractionSpec spec) throws DataExtractionServiceException
	{
		return 0;
	}

}
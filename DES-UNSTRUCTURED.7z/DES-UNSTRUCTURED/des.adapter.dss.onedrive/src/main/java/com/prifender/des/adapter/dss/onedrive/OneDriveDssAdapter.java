package com.prifender.des.adapter.dss.onedrive;

import static com.prifender.des.util.DatabaseUtil.createDir;
import static com.prifender.des.util.DatabaseUtil.getConvertedDate;
import static com.prifender.des.util.DatabaseUtil.getUUID;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.graph.authentication.IAuthenticationProvider;
import com.microsoft.graph.http.IHttpRequest;
import com.microsoft.graph.models.extensions.DriveItem;
import com.microsoft.graph.models.extensions.User;
import com.microsoft.graph.requests.extensions.GraphServiceClient;
import com.microsoft.graph.requests.extensions.IDriveItemCollectionPage;
import com.microsoft.graph.requests.extensions.IDriveItemCollectionRequestBuilder;
import com.microsoft.graph.requests.extensions.IDriveItemRequestBuilder;
import com.microsoft.graph.requests.extensions.IUserCollectionPage;
import com.microsoft.graph.requests.extensions.IUserCollectionRequestBuilder;
import com.microsoft.graph.requests.extensions.GraphServiceClient.Builder2;
import com.prifender.des.DataExtractionServiceException;
import com.prifender.des.controller.DataExtractionContext;
import com.prifender.des.controller.DataExtractionThread;
import com.prifender.des.controller.DataSourceAdapter;
import com.prifender.des.model.ConnectionParamDef;
import com.prifender.des.model.ConnectionParamDef.TypeEnum;
import com.prifender.des.model.ConnectionStatus;
import com.prifender.des.model.DataExtractionJob;
import com.prifender.des.model.DataExtractionSpec;
import com.prifender.des.model.DataExtractionTask;
import com.prifender.des.model.DataSource;
import com.prifender.des.model.DataSourceType;
import com.prifender.des.model.FileMetaInfo;
import com.prifender.des.model.Metadata;
import com.prifender.des.model.Problem;

@Component
public class OneDriveDssAdapter extends DataSourceAdapter
{

	private static final int MAX_FILES_THRESHOLD = 10;

	// OneDrive API Token
	public static final String PARAM_ACCESS_TOKEN_ID = "AccessToken";
	public static final String PARAM_ACCESS_TOKEN_LABEL = "Access Token";
	public static final String PARAM_ACCESS_TOKEN_DESCRIPTION = "AccessToken, which is required for authorization";

	public static final ConnectionParamDef PARAM_ACCESS_TOKEN = new ConnectionParamDef().id(PARAM_ACCESS_TOKEN_ID).label(PARAM_ACCESS_TOKEN_LABEL).description(PARAM_ACCESS_TOKEN_DESCRIPTION).type(TypeEnum.STRING);

	public static final String TYPE_ID = "OneDrive";
	public static final String TYPE_LABEL = "OneDrive";

	private static final DataSourceType TYPE = new DataSourceType().id(TYPE_ID).label(TYPE_LABEL).addConnectionParamsItem(PARAM_USER).addConnectionParamsItem(PARAM_ACCESS_TOKEN);

	List<FileMetaInfo> fileMetaInfoList = new ArrayList<>();

	@Override
	public DataSourceType getDataSourceType()
	{
		return TYPE;
	}

	@Override
	public ConnectionStatus testConnection(DataSource ds) throws DataExtractionServiceException
	{
		Builder2 graphServiceClient = null;

		try
		{
			graphServiceClient = getConnection(ds);

			if( graphServiceClient != null )
			{
				final String userName = getConnectionParam(ds, PARAM_USER_ID);

				String userPrincipal = getUserPrincipal(graphServiceClient, userName);

				if( null != userPrincipal )
				{
					return new ConnectionStatus().code(ConnectionStatus.CodeEnum.SUCCESS).message("OneDrive Authorization Successful.");
				}
			}
		}
		catch ( Exception e )
		{
			return new ConnectionStatus().code(ConnectionStatus.CodeEnum.FAILURE).message(e.getMessage());
		}

		return new ConnectionStatus().code(ConnectionStatus.CodeEnum.FAILURE).message("OneDrive Authorization Failed.");
	}

	private Builder2 getConnection(final DataSource ds)
	{
		final String accessToken = getConnectionParam(ds, PARAM_ACCESS_TOKEN_ID);

		IAuthenticationProvider iAuthenticationProvider = new IAuthenticationProvider()
		{
			@Override
			public void authenticateRequest(IHttpRequest arg0)
			{
				arg0.addHeader("Accept", "application/json");
				arg0.addHeader("Content-Type", "application/json");
				arg0.addHeader("Authorization", "Bearer " + accessToken);
			}
		};
		return GraphServiceClient.builder().authenticationProvider(iAuthenticationProvider);
	}

	private String getUserPrincipal(Builder2 graphServiceClient, String userPrincipal)
	{
		IUserCollectionRequestBuilder iUserCollectionRequestBuilder = graphServiceClient.buildClient().users();

		IUserCollectionPage iUserCollectionPage = iUserCollectionRequestBuilder.buildRequest().get();

		List<User> list = iUserCollectionPage.getCurrentPage();

		for (User user : list)
		{
			if( userPrincipal.equals(user.userPrincipalName) )
			{
				return userPrincipal;
			}

		}
		return null;
	}

	@Override
	public Metadata getMetadata(final DataSource ds) throws DataExtractionServiceException
	{
		Metadata metadata = getMetadataForUnstructuredDS(ds);
		return metadata;
	}

	@Override
	public StartResult startDataExtractionJob(DataSource ds, DataExtractionSpec spec, final int containersCount) throws DataExtractionServiceException
	{
		StartResult startResult = null;
		try
		{
			final DataExtractionJob job = createDataExtractionJob(ds, spec);
			String adapterHome = createDir(this.desHome, TYPE_LABEL);
			final DataExtractionContext context = new DataExtractionContext(this, getDataSourceType(), ds, spec, job, this.messaging, this.pendingTasksQueue, this.pendingTasksQueueName, TYPE_LABEL, this.encryption);
			final DataExtractionThread dataExtractionExecutor = new OneDriveDataExtractionExecutor(context, adapterHome, containersCount);
			this.threadPool.execute(dataExtractionExecutor);
			startResult = new StartResult(job, dataExtractionExecutor);
		}
		catch ( Exception exe )
		{
			throw new DataExtractionServiceException(new Problem().code("unknownDataExtractionJob").message(exe.getMessage()));

		}
		return startResult;
	}

	public class OneDriveDataExtractionExecutor extends DataExtractionThread
	{
		private final int containersCount;

		public OneDriveDataExtractionExecutor(final DataExtractionContext context, final String adapterHome, final int containersCount) throws DataExtractionServiceException
		{
			super(context);
			this.containersCount = containersCount;
		}

		@Override
		protected List<DataExtractionTask> runDataExtractionJob() throws Exception
		{
			final DataSource ds = this.context.ds;
			final DataExtractionSpec spec = this.context.spec;
			final DataExtractionJob job = this.context.job;

			return getDataExtractionTasks(ds, spec, job, containersCount);
		}

		private List<DataExtractionTask> getDataExtractionTasks(DataSource ds, DataExtractionSpec spec,

				DataExtractionJob job, int containersCount) throws DataExtractionServiceException
		{

			List<DataExtractionTask> dataExtractionJobTasks = new ArrayList<DataExtractionTask>();

			int objectsCount = 0;
			int tasksCount = 0;

			try
			{
				synchronized (job)
				{
					job.setOutputMessagingQueue("DES-" + job.getId());

					job.objectsExtracted(0);

					job.setTasksCount(tasksCount);

					job.setObjectCount(objectsCount);
				}

				List<FileMetaInfo> filesInfoList = getFilesInfoList(ds);
				
				objectsCount = filesInfoList.size();

				for (int i = 0; i < filesInfoList.size(); i += 10)
				{
					List<FileMetaInfo> tmpFilesInfoList = new ArrayList<>(MAX_FILES_THRESHOLD);

					int start = i;

					int end = (i + 10);

					if( start >= objectsCount )
					{
						start = objectsCount;
					}
					if( end > objectsCount )
					{
						end = objectsCount;
					}

					tmpFilesInfoList = filesInfoList.subList(start, end);

					dataExtractionJobTasks.add(getDataExtractionTask(ds, spec, job, tmpFilesInfoList));

					tasksCount++;
				}
			}
			catch ( Exception e )
			{
				throw new DataExtractionServiceException(new Problem().code("unknownDataExtractionJob").message(e.getMessage()));
			}
			synchronized (job)
			{
				job.setTasksCount(tasksCount);
				job.setObjectCount(objectsCount);
			}

			return dataExtractionJobTasks;
		}

		private final DataExtractionTask getDataExtractionTask(DataSource ds, DataExtractionSpec spec,

				DataExtractionJob job, List<FileMetaInfo> filesInfoList) throws DataExtractionServiceException
		{

			DataExtractionTask dataExtractionTask = new DataExtractionTask();

			try
			{

				final String accessToken = getConnectionParam(ds, PARAM_ACCESS_TOKEN_ID);

				Map<String, String> contextParams = getContextParams(job.getId(), accessToken, filesInfoList, spec.getScope().name(), String.valueOf(spec.getSampleSize()));

				dataExtractionTask.taskId("DES-Task-" + getUUID())

						.jobId(job.getId())

						.typeId(TYPE_ID)

						.contextParameters(contextParams)

						.numberOfFailedAttempts(0);
			}
			catch ( Exception e )
			{
				throw new DataExtractionServiceException(new Problem().code("unknownDataExtractionJob").message(e.getMessage()));
			}
			return dataExtractionTask;
		}

		private Map<String, String> getContextParams(String jobId, String accessToken, List<FileMetaInfo> filesInfoList, final String extractionScope, final String sampleSize) throws IOException
		{

			ObjectMapper mapperObj = new ObjectMapper();

			String filesInfo = mapperObj.writeValueAsString(filesInfoList);

			Map<String, String> contextParams = new LinkedHashMap<>();

			contextParams.put("JOB_STARTDATETIME", getConvertedDate(new Date()));

			contextParams.put("JOB_ID", jobId);
			
			contextParams.put("ACCESS_TOKEN", accessToken);

			contextParams.put("FILES_INFO", filesInfo);

			contextParams.put("SCOPE", extractionScope);

			contextParams.put("SAMPLESIZE", sampleSize);

			return contextParams;

		}

		private List<FileMetaInfo> getFilesInfoList(final DataSource ds) throws DataExtractionServiceException
		{

			List<FileMetaInfo> filesInfoList = new ArrayList<>();
			try
			{

				Builder2 graphServiceClient = getConnection(ds);

				if( graphServiceClient != null )
				{

					IUserCollectionRequestBuilder iUserCollectionRequestBuilder = graphServiceClient.buildClient().users();

					IUserCollectionPage iUserCollectionPage = iUserCollectionRequestBuilder.buildRequest().get();

					List<User> list = iUserCollectionPage.getCurrentPage();

					for (User user : list)
					{
						IDriveItemRequestBuilder iDriveItemRequestBuilder = graphServiceClient.buildClient().me().drives(user.id).root();

						IDriveItemCollectionRequestBuilder iDriveItemCollectionRequestBuilder = iDriveItemRequestBuilder.children();

						IDriveItemCollectionPage iDriveItemCollectionPage = iDriveItemCollectionRequestBuilder.buildRequest().get();

						List<DriveItem> driveItemList = iDriveItemCollectionPage.getCurrentPage();

						for (DriveItem driveItem : driveItemList)
						{
							List<FileMetaInfo> listOfFileMetaInfo = getFileMetaInfoList(user.id, driveItem, graphServiceClient);

							filesInfoList.addAll(listOfFileMetaInfo);

							fileMetaInfoList.clear();
						}
					}

				}
			}
			catch ( Exception e )
			{
				throw new DataExtractionServiceException(new Problem().code("unknownConnection").message(e.getMessage()));
			}

			return filesInfoList;

		}

		List<FileMetaInfo> getFileMetaInfoList(String userId, DriveItem driveItem, Builder2 graphServiceClient)
		{
			IDriveItemRequestBuilder iDriveItemRequestBuilder = null;

			String[] fileTypes = new String[] { "doc", "docx", "xls", "xlsx", "ppt", "pptx", "odt", "ods", "odp", "txt", "rtf", "pdf" };

			List<String> reqDocTypeList = new ArrayList<String>(Arrays.asList(fileTypes));

			String fileExtension = driveItem.name.substring(driveItem.name.lastIndexOf(".") + 1);

			if( reqDocTypeList.contains(fileExtension) )
			{
				FileMetaInfo fileMetaInfo = new FileMetaInfo();
				iDriveItemRequestBuilder = graphServiceClient.buildClient().me().drives(userId).items(driveItem.id);
				fileMetaInfo.setFileType(userId);
				fileMetaInfo.fileId(driveItem.id);
				fileMetaInfo.setFileName(driveItem.name);
				fileMetaInfo.setFileExtension(fileExtension);
				fileMetaInfo.setFileSize(driveItem.size.intValue());
				fileMetaInfo.setFilePath(driveItem.webUrl);
				fileMetaInfo.setFileDownloadLink(iDriveItemRequestBuilder.getRequestUrl());
				fileMetaInfoList.add(fileMetaInfo);
			}
			else
			{
				iDriveItemRequestBuilder = graphServiceClient.buildClient().me().drives(userId).items(driveItem.id);
				IDriveItemCollectionRequestBuilder subiDriveItemCollectionRequestBuilder = iDriveItemRequestBuilder.children();
				IDriveItemCollectionPage subIDriveItemCollectionPage = subiDriveItemCollectionRequestBuilder.buildRequest().get();
				List<DriveItem> subDriveItemList = subIDriveItemCollectionPage.getCurrentPage();

				if( subDriveItemList.size() > 0 )
				{
					for (DriveItem subDriveItem : subDriveItemList)
					{
						getFileMetaInfoList(userId, subDriveItem, graphServiceClient);
					}
				}

			}
			return fileMetaInfoList;
		}
	}

	@Override
	public int getCountRows(DataSource ds, DataExtractionSpec spec) throws DataExtractionServiceException
	{
		return 0;
	}

}
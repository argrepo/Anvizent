package com.datamodel.anvizent.security;

import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;

/**
 * 
 * @author rakesh.gajula
 *
 */
public class CustomSecurityAuthenticationProvider implements AuthenticationProvider {

	public CustomSecurityAuthenticationProvider(CustomSecurityUserDetailsServiceImpl customSecurityUserDetailsServiceImpl) {
	}

	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		return null;
	}

	@Override
	public boolean supports(Class<?> authentication) {
		return true;
	}

}

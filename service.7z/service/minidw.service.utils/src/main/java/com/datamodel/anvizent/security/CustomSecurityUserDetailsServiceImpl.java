package com.datamodel.anvizent.security;

/**
 * 
 * @author rakesh.gajula
 *
 */

public class CustomSecurityUserDetailsServiceImpl  
{

}

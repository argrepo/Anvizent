package com.anvizent.minidw.service.utils.model;

public class ETLjobExecutionMessages {
	private String inputStreamMsg;
	private String errorStreamMsg;
	private String javaCommandForJobExection;

	private int status;

	public String getInputStreamMsg() {
		return inputStreamMsg;
	}

	public void setInputStreamMsg(String inputStreamMsg) {
		this.inputStreamMsg = inputStreamMsg;
	}

	public String getErrorStreamMsg() {
		return errorStreamMsg;
	}

	public void setErrorStreamMsg(String errorStreamMsg) {
		this.errorStreamMsg = errorStreamMsg;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getJavaCommandForJobExection() {
		return javaCommandForJobExection;
	}

	public void setJavaCommandForJobExection(String javaCommandForJobExection) {
		this.javaCommandForJobExection = javaCommandForJobExection;
	}
}

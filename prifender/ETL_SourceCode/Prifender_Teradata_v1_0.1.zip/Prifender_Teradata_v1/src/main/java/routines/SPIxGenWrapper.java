package routines;
import java.lang.reflect.*;
import java.util.*;
public class SPIxGenWrapper {
   @SuppressWarnings({ "rawtypes", "unchecked" })
public static Map flowToMap(Class<?> flowClass, Object flow) {
        Map retMap = new HashMap();
        try {
            Field[] fields  = flowClass.getFields();
            List<Field> fl = Arrays.asList(fields);
            for(Field f : fl) {
                retMap.put(f.getName(), f.get(flow));
            }
        } catch(Exception e) {System.out.println(e);}
        
        return (retMap);
   }
}
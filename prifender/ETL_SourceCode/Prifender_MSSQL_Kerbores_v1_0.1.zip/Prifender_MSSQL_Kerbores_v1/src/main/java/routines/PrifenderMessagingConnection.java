package routines;

import java.io.IOException;

import com.prifender.des.connection.GetMessagingQueue;
import com.prifender.messaging.api.MessagingQueue;


public final class PrifenderMessagingConnection {

	 public static MessagingQueue getConnect(String queueName) throws IOException{
		 
		 GetMessagingQueue messagingQueue = new GetMessagingQueue();
	   	 return messagingQueue.getQueue(queueName);
	 }
}

package routines;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import routines.system.TypeConvert;

public class GetBaseCurrencyAmount_v2 {

	@SuppressWarnings("rawtypes")
	public static BigDecimal get(String from_currency_code, String to_currency_code, BigDecimal amount, Date transaction_date, Map < String, Object > globalMap) {
        
		List curr = (List) globalMap.get("currency");
		
		if (curr.size()==0||from_currency_code == null || from_currency_code.equals("unknown") || from_currency_code.equals("") || to_currency_code == null || to_currency_code.equals("unknown") || to_currency_code.equals("") || amount == null || transaction_date == null)

		return amount;

		Map Cur;

		int start = 0,
		end = curr.size() - 1,
		mid = 0;
        
		if (TypeConvert.Date2Long(transaction_date) > (Long)((Map)curr.get(end)).get("CURRENCY_START_PERIOD")){
			
			Long lastCurrDate = (Long)((Map)curr.get(end)).get("CURRENCY_START_PERIOD");
			
				while(end > 0 ){
					   
					if (lastCurrDate >  (Long)((Map)curr.get(end)).get("CURRENCY_START_PERIOD"))
						break;
					
				if (((String)((Map) curr.get(end)).get("From_Currency_Code")).equals(from_currency_code) && ((String)((Map) curr.get(end)).get("To_Currency_Code")).equals(to_currency_code) ){
					return amount.multiply(((BigDecimal)((Map) curr.get(end)).get("EXCHANGE_RATE")));
				}
				
				end--;		
								
				}
		}
		
		while (start < end) {

			mid = start + (end - start) / 2;

			if (TypeConvert.Date2Long(transaction_date) < (Long)(((Map) curr.get(mid)).get("CURRENCY_START_PERIOD"))) {
				end = mid;
				continue;

			} else if (TypeConvert.Date2Long(transaction_date) > (Long)(((Map) curr.get(mid)).get("CURRENCY_END_PERIOD"))) {

				start = mid + 1;

				continue;

			} else {

				for (int i = start; i <= end; i++) {

					Cur = (Map) curr.get(i);

					if ((Long) Cur.get("CURRENCY_START_PERIOD") <= TypeConvert.Date2Long(transaction_date) && (Long) Cur.get("CURRENCY_END_PERIOD") > TypeConvert.Date2Long(transaction_date) && Cur.get("From_Currency_Code").equals(from_currency_code) && Cur.get("To_Currency_Code").equals(to_currency_code)) {
						return amount.multiply((BigDecimal) Cur.get("EXCHANGE_RATE"));
					}else if ((Long) Cur.get("CURRENCY_START_PERIOD") <= TypeConvert.Date2Long(transaction_date) && i+1< curr.size() && (Long) ((Map) curr.get(i+1)).get("CURRENCY_START_PERIOD") > TypeConvert.Date2Long(transaction_date) && Cur.get("From_Currency_Code").equals(from_currency_code) && Cur.get("To_Currency_Code").equals(to_currency_code)) {
						return amount.multiply((BigDecimal) Cur.get("EXCHANGE_RATE"));
					}
				}
				break;

			}

		}

		return amount;
	}
}
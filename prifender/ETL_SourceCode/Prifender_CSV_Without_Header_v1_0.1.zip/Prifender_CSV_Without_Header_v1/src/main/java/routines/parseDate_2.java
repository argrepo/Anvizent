package routines;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class parseDate_2 {

    public static Date parse(String patterns,String inputDate) {
    	List<String> patternsList = Arrays.asList(patterns.split("@#"));
    	
    	List<SimpleDateFormat> knownPatterns = new ArrayList<SimpleDateFormat>();
    	
    	for (String pat : patternsList) {
    		knownPatterns.add(new SimpleDateFormat(pat));
    	}

    	for (SimpleDateFormat pattern : knownPatterns) {
    		pattern.setLenient(false);
    	    try {
    	        return new Date(pattern.parse(inputDate).getTime());

    	    } catch (ParseException pe) {
    	    }
    	}
    	System.err.println("No known Date format found: " + inputDate);
    	return null;
    }
}

package routines;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class GetBaseCurrencyAmount {

    public static BigDecimal get(String from_currency_code,String to_currency_code, BigDecimal amount,Date transaction_date,Map<String, Object> globalMap) {
        @SuppressWarnings("rawtypes")
		List curr = (List) globalMap.get("currency");
        Map Cur;
        for(Object retMap :curr){ 
        	 Cur =(Map) retMap;
     		
        	if(TalendDate.compareDate((Date)Cur.get("CURRENCY_START_PERIOD"), transaction_date)>=0 &&
     				TalendDate.compareDate( transaction_date,(Date)Cur.get("CURRENCY_END_PERIOD"))==-1 &&
     						Cur.get("From_Currency_Code").equals(from_currency_code) &&
     						Cur.get("To_Currency_Code").equals(to_currency_code)){
        		// System.out.println((Date)Cur.get("CURRENCY_START_PERIOD")+"|"+(Date)Cur.get("CURRENCY_END_PERIOD")+"|"+Cur.get("From_Currency_Code").toString()+"|"+Cur.get("To_Currency_Code").toString()+"|"+(BigDecimal)Cur.get("EXCHANGE_RATE"));
        		 return amount.multiply((BigDecimal)Cur.get("EXCHANGE_RATE"));
        	}
        		
          }  
    	
 		return amount;
}
}

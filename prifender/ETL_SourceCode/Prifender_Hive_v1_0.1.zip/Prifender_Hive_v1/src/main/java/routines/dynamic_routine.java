package routines;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;




public class dynamic_routine {

    public static String  test_query() throws IOException {
     BufferedReader var = new BufferedReader(new FileReader("D:/test_1/samp_1.csv"));
     String str;
     while ((str = var.readLine()) != null) {
      //System.out.println("FirstLine : " + str);
      break;
     }
        String Col[]=str.split(",");

        StringBuilder sb = new StringBuilder("create table demo(");
     for(int i = 0 ; i< Col.length  ; i++){
      sb.append(Col[i]);
      sb.append(" ");
      sb.append("varchar(100)");
      sb.append(",");
     }
     sb.delete(sb.lastIndexOf(","),sb.lastIndexOf(",")+1 );
     sb.append(") ");
     return sb.toString() ;
     }
    
    public static String main(String[] args) throws IOException {
     return test_query();
    }
}

package routines;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

public class parseDate {

    public static Date parse(String patterns, String inputDate) {
        if (inputDate == null || inputDate.equals("") || inputDate.equalsIgnoreCase("NULL")) {
            return null;
        }

        try {
            Long unix_timestamp = Long.parseLong(inputDate);
            Date date = unixToDate(unix_timestamp);
            return date;
        } catch (Exception e) {
            List < String > patternsList = Arrays.asList(patterns.split("@#"));

            List < SimpleDateFormat > knownPatterns = new ArrayList < SimpleDateFormat > ();

            for (String pat: patternsList) {
                knownPatterns.add(new SimpleDateFormat(pat));
            }

            for (SimpleDateFormat pattern: knownPatterns) {
                pattern.setLenient(false);
                try {
                    return new Date(pattern.parse(inputDate).getTime());

                } catch (ParseException pe) {}
            }
        }
        System.err.println("No known Date format found: " + inputDate);
        return null;
    }

    
    public static Date parse(String patterns, String inputDate, String srctimezone, String tgttimezone) {
    	
        if (inputDate == null || inputDate.equals("") || inputDate.equalsIgnoreCase("NULL")) {
            return null;
        }

        try {
            Long unix_timestamp = Long.parseLong(inputDate);
            Date date = unixToDate(unix_timestamp,srctimezone,tgttimezone);
            return date;
        } catch (Exception e) {
            List < String > patternsList = Arrays.asList(patterns.split("@#"));

            List < SimpleDateFormat > knownPatterns = new ArrayList < SimpleDateFormat > ();

            for (String pat: patternsList) {
                knownPatterns.add(new SimpleDateFormat(pat));
            }
            
            TimeZone fromTimeZone = TimeZone.getTimeZone(srctimezone); 
            
            TimeZone toTimeZone = TimeZone.getTimeZone(tgttimezone);
            
            for (SimpleDateFormat pattern: knownPatterns) {
                pattern.setLenient(false);
                try {
                    return convertTimeZone(new Date(pattern.parse(inputDate).getTime()), fromTimeZone, toTimeZone);
                } catch (ParseException pe) {}
            }
        }
        System.err.println("No known Date format found: " + inputDate);
        return null;
    }
    
    private static Date unixToDate(Long unix_timestamp, String srctimezone, String tgttimezone) {
    	
        long timestamp = unix_timestamp % 1000 == 0 ? unix_timestamp : unix_timestamp * 1000;
        
        TimeZone fromTimeZone = TimeZone.getTimeZone(srctimezone); 
        
        TimeZone toTimeZone = TimeZone.getTimeZone(tgttimezone);
        
        try {
            SimpleDateFormat dateFormatGmt = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");
            dateFormatGmt.setTimeZone(TimeZone.getTimeZone(srctimezone));
            SimpleDateFormat dateFormatLocal = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");
            Date date = dateFormatLocal.parse(dateFormatGmt.format(new Date(timestamp)));
            return convertTimeZone(date, fromTimeZone, toTimeZone);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println(e.getStackTrace());
        }
		return null;
	}


	private static Date unixToDate(Long unix_timestamp) throws Exception {

        long timestamp = unix_timestamp % 1000 == 0 ? unix_timestamp : unix_timestamp * 1000;
        
        TimeZone fromTimeZone = TimeZone.getTimeZone("GMT"); // source time zone
        TimeZone toTimeZone = TimeZone.getTimeZone("GMT-4"); // target time zone
        
        try {
            SimpleDateFormat dateFormatGmt = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");
            dateFormatGmt.setTimeZone(TimeZone.getTimeZone("GMT"));
            SimpleDateFormat dateFormatLocal = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");
            Date date = dateFormatLocal.parse(dateFormatGmt.format(new Date(timestamp)));
            return convertTimeZone(date, fromTimeZone, toTimeZone);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println(e.getStackTrace());
        }
        return null;
    }

    public static Date convertTimeZone(Date date, TimeZone fromTimeZone, TimeZone toTimeZone) {
        long fromTimeZoneOffset = getTimeZoneUTCAndDSTOffset(date, fromTimeZone);
        long toTimeZoneOffset = getTimeZoneUTCAndDSTOffset(date, toTimeZone);

        return new Date(date.getTime() + (toTimeZoneOffset - fromTimeZoneOffset));
    }


    private static long getTimeZoneUTCAndDSTOffset(Date date, TimeZone timeZone) {
        long timeZoneDSTOffset = 0;
        if (timeZone.inDaylightTime(date)) {
            timeZoneDSTOffset = timeZone.getDSTSavings();
        }

        return timeZone.getRawOffset() + timeZoneDSTOffset;
    }
}
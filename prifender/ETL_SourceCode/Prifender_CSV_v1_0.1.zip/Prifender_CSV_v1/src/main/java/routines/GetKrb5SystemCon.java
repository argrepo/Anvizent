package routines;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class GetKrb5SystemCon {
	
	 static String KRB_CONFIG ;
	 static String KRB_LOGIN_CONFIG;
	
	
	
	public static Connection getDataBaseConnection(String hostName,String port,String databaseName,String fqdn,String realm,Boolean integratedSecurity,String authenticationScheme,String encryptionMethod,String userName,String password, String ADMINHOSTNAME, String instancename) throws SQLException, ClassNotFoundException {
		
		  KRB_CONFIG =
		           "[libdefaults]\n" +
		                   "\tdefault_realm = "+realm+ "\n" +
		                   "\t\n" +
		                   "[domain_realm]\n" +
		                   "    ."+realm.toLowerCase()+" ="+realm+ "\n" +
		                   "    "+realm.toLowerCase()+" = "+realm+ "\n" +
		                   " \n" +
		                   "[realms]\n" +
		                   " "+realm+ " = {\n" +
		                   "\tadmin_server = "+ADMINHOSTNAME+"\n" +
		                   "\tkdc = "+ADMINHOSTNAME+"\n" +
		                   " }";
		  KRB_LOGIN_CONFIG = "login {"+
		
				 "com.sun.security.auth.module.Krb5LoginModule required \n " +			 

				 "doNotPrompt=true \n" +

				 "useTicketCache=true; \n" +

				 "};";
		  
		//System.out.println(KRB_CONFIG);
		//System.out.println(KRB_LOGIN_CONFIG);
		Connection connection = null;
		getKrb5SystemCon();
		String driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
		String serverSpn = fqdn+":"+port+"@"+realm;
		Class.forName(driver);
		String url = "jdbc:sqlserver://" + hostName + ":" + port + ";" + "ServerSpn=" + serverSpn + ";integratedSecurity="+ integratedSecurity + ";authenticationScheme=" + authenticationScheme + ";EncryptionMethod=" + encryptionMethod +((databaseName != null && !databaseName.isEmpty()) ? "databaseName=" + databaseName + ";" : "" ) + ((instancename != null && !instancename.isEmpty())? "instancename=" + instancename + ";" : "" ) +"userName ="+userName +";password="+password;
		connection = DriverManager.getConnection(url);
		return connection;
	}
	
	public static void getKrb5SystemCon() {

		System.setProperty("sun.security.krb5.debug", "true");
		System.setProperty("java.security.krb5.config", System.getenv("KRB_CONFIG"));
		System.setProperty("java.security.auth.login.config", System.getenv("KRB_LOGIN_CONFIG"));

		writeToFile(System.getenv("KRB_LOGIN_CONFIG"), KRB_LOGIN_CONFIG);
		writeToFile(System.getenv("KRB_CONFIG"), KRB_CONFIG);

	}
	private static  void writeToFile(String getenv, String krb5_Config) {
			
			createDir(getenv);
			
			FileWriter fileWriter;
			BufferedWriter bufferedWriter = null;
			try {
				fileWriter = new FileWriter(getenv);
				bufferedWriter = new BufferedWriter(fileWriter);
				bufferedWriter.write(krb5_Config);
			} catch (IOException e) {
				System.out.println(e.getMessage());
			} finally {
				try {
					bufferedWriter.flush();
					bufferedWriter.close();
				} catch (IOException e) {
					System.out.println(e.getMessage());
				}
			}
		}
	
	private static String createDir(String dirName) {
		if (!dirName.equals("")) {
			if (!new File(dirName).exists()) {
				try {
					new File(dirName).createNewFile();
				} catch (IOException e) {
					System.out.println(e.getMessage());
				}
			}
		}
		return dirName;
	}
}

package routines;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
public class BuildQuery {
    public static String  test_query() throws IOException {
    
	BufferedReader in = new BufferedReader(new FileReader("D:\\Dynamic_Schema\\DL_Bookings.csv"));
     String str;
     while ((str = in.readLine()) != null) {
      System.out.println("FirstLine : " + str);
      break;
     }
        String Col[]=str.split("\\t");
        StringBuilder sb = new StringBuilder("create table demo(");
     for(int i = 0 ; i< Col.length  ; i++){
      sb.append(Col[i]);
      sb.append(" ");
      sb.append("varchar(100)");
      sb.append(",");
     }
     sb.delete(sb.lastIndexOf(","),sb.lastIndexOf(",")+1 );
     sb.append("); ");
     in.close();
     return sb.toString() ;
     
     
    }
    
    public static String main(String[] args) throws IOException {
     return test_query();
    }
}